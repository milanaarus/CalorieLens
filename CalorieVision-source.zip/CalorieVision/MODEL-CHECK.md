# Проверка пищевых моделей · 18 октября 2026

Это небольшой диагностический набор, а не оценка общей точности. Возможное пересечение публичных фотографий с обучением неизвестно. Масса и точность калорий по этим изображениям не проверяются.

| Пример | Найдено новой связкой | Ограничение |
|---|---|---|
| Bright_red_tomato_and_cross_section02.jpg | Помидор |  |
| Dum_Biryani_Plate.jpg | Рис отварной | Рис найден; курица пропущена |
| Friday_dinner_-_Curry_chicken_with_bell_peppers_and_rice_-_02.jpg | Мясо птицы (уточните вид и приготовление), Рис отварной | Рис и птица найдены; овощи пропущены, вид и рецепт птицы не определены |
| Parboiled_rice_with_chicken,_peppers,_cucurbita,_peas_and_tomato.jpg | Нет продуктов | Сложное смешанное блюдо не распознано |
| Red_bell_pepper.jpg | Перец красный |  |
| Strawberry_BNC.jpg | Клубника |  |
| test-banana.jpg | Банан |  |
| blank | Нет продуктов | Синтетический отрицательный пример, не реальная фотография |
| red-disk | Нет продуктов | Синтетический отрицательный пример, не реальная фотография |

Первую пищевую YOLO и YOLO-World проверили отдельно. Первую нельзя использовать для красных овощей без доработки: перец был назван помидором; YOLO-World тоже путала фрукты и овощи. В новой связке роли моделей ограничены, эти результаты не скрыты.

## Источники фотографий
- [Bright_red_tomato_and_cross_section02.jpg](https://commons.wikimedia.org/wiki/File:Bright%20red%20tomato%20and%20cross%20section02.jpg) — 





	
		
		fir0002  flagstaffotos [at] gmail.com
		Canon 20D + Sigma 150mm f/2.8

		
                    
                         
                         
                         
                         
                         
                         
		
	

; GFDL 1.2. Для проверки использована уменьшенная копия.
- [Red_bell_pepper.jpg](https://commons.wikimedia.org/wiki/File:Red%20bell%20pepper.jpg) — AntanO; CC BY-SA 4.0. Для проверки использована уменьшенная копия.
- [Strawberry_BNC.jpg](https://commons.wikimedia.org/wiki/File:Strawberry%20BNC.jpg) — Prathyush Thomas; GFDL 1.2. Для проверки использована уменьшенная копия.
- [Dum_Biryani_Plate.jpg](https://commons.wikimedia.org/wiki/File:Dum%20Biryani%20Plate.jpg) — Umesh Tongbra; CC BY-SA 3.0. Для проверки использована уменьшенная копия.
- [Parboiled_rice_with_chicken,_peppers,_cucurbita,_peas_and_tomato.jpg](https://commons.wikimedia.org/wiki/File:Parboiled%20rice%20with%20chicken%2C%20peppers%2C%20cucurbita%2C%20peas%20and%20tomato.jpg) — Petar Milošević; CC BY-SA 4.0. Для проверки использована уменьшенная копия.
- [Friday_dinner_-_Curry_chicken_with_bell_peppers_and_rice_-_02.jpg](https://commons.wikimedia.org/wiki/File:Friday%20dinner%20-%20Curry%20chicken%20with%20bell%20peppers%20and%20rice%20-%2002.jpg) — Infrogmation of New Orleans; CC BY-SA 4.0. Для проверки использована уменьшенная копия.
- Банан: Evan-Amos; CC BY-SA 3.0; https://commons.wikimedia.org/wiki/File:Banana-Single.jpg

## Что проверять дальше
Нужны собственные фотографии вашей столовой, которых не было при выборе моделей: одиночные продукты, несколько компонентов рядом, перемешанная еда, разное освещение и красная посуда. Отмечать верные, ложные и пропущенные позиции отдельно. Не измерять точность на тех же примерах, по которым настраивались пороги.
