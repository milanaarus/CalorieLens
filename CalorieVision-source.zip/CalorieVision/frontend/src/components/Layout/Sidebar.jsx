import Icon from '../../components/Icon';
import { Link, NavLink, useNavigate } from 'react-router-dom';
import '../../styles/layout.css';

const Sidebar = () => {
  const navigate = useNavigate();
  const user = JSON.parse(localStorage.getItem('user') || '{}');

  const menuItems = [
    { path: '/dashboard', label: 'Обзор', icon: 'home' },
    { path: '/scan', label: 'Сканировать', icon: 'camera' },
    { path: '/history', label: 'История', icon: 'calendar' },
    { path: '/profile', label: 'Профиль', icon: 'user' },
  ];

  const handleLogout = () => {
    localStorage.removeItem('token');
    localStorage.removeItem('user');
    navigate('/login');
  };

  return (
    <aside className="sidebar">
      <Link className="sidebar-logo" to="/" aria-label="CalorieVision — на главную" title="На главную страницу">CalorieVision</Link>

      {user.name && (
        <div className="sidebar-user">
          <div className="user-avatar-small">
            {user.name.charAt(0).toUpperCase()}
          </div>
          <div className="user-info-small">
            <div className="user-name-small">{user.name}</div>
            <div className="user-email-small">{user.email}</div>
          </div>
        </div>
      )}

      <nav className="sidebar-nav">
        {menuItems.map((item) => (
          <NavLink
            key={item.path}
            to={item.path}
            className={({ isActive }) =>
              `nav-item ${isActive ? 'active' : ''}`
            }
            end
          >
            <Icon name={item.icon} />
            <span>{item.label}</span>
          </NavLink>
        ))}
      </nav>

      <button className="logout-btn" onClick={handleLogout}>
        <Icon name="logout" /> Выйти
      </button>
    </aside>
  );
};

export default Sidebar;
