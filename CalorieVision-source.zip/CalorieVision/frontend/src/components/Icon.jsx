const paths = {
  home: ['M3 10 12 3l9 7','M5 9v12h14V9','M9 21v-7h6v7'],
  camera: ['M4 7h4l2-3h4l2 3h4v13H4z','M16 13a4 4 0 1 1-8 0 4 4 0 0 1 8 0'],
  plate: ['M17 12a5 5 0 1 1-10 0 5 5 0 0 1 10 0','M3 3v6m3-6v6M3 7h3M4.5 9v12','M21 3v18m0-18c-3 2-3 7 0 8'],
  calendar: ['M5 5h14v16H5z','M8 3v4m8-4v4M5 10h14','M8 14h2m4 0h2m-8 3h2'],
  user: ['M16 7a4 4 0 1 1-8 0 4 4 0 0 1 8 0','M4 21v-2a8 8 0 0 1 16 0v2'],
  logout: ['M10 3H4v18h6','M8 12h13m-5-5 5 5-5 5'],
  upload: ['M12 16V3m-5 5 5-5 5 5','M4 15v6h16v-6'],
  search: ['M17 10a7 7 0 1 1-14 0 7 7 0 0 1 14 0','m15 15 6 6'],
  reset: ['M3 11a9 9 0 1 1 2 7','M3 4v7h7'],
  close: ['m6 6 12 12M18 6 6 18'],
  check: ['m4 12 5 5L20 6'],
  edit: ['m15 4 5 5-11 11-6 1 1-6z','m13 6 5 5'],
  save: ['M4 3h13l4 4v14H4z','M8 3v6h8V3','M8 21v-7h9v7'],
  trash: ['M3 6h18M8 6V3h8v3','M5 6l1 15h12l1-15','M10 10v7m4-7v7'],
  sun: ['M16 12a4 4 0 1 1-8 0 4 4 0 0 1 8 0','M12 2v2m0 16v2M2 12h2m16 0h2M5 5l2 2m10 10 2 2M5 19l2-2M17 7l2-2'],
  moon: ['M20 15A9 9 0 0 1 9 3 9 9 0 1 0 20 15'],
  leaf: ['M20 3C9 2 3 6 4 13c1 8 13 9 16-10Z','M4 21 15 9'],
};
export default function Icon({name='plate',size=22,className=''}){
 return <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true" focusable="false" className={`cv-icon ${className}`}>{(paths[name]||paths.plate).map((d,i)=><path d={d} key={i}/>)}</svg>;
}
