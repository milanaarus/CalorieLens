import { useEffect, useRef, useState } from 'react';
import * as THREE from 'three';
import { createPlate, createFood, dishes } from './food3d';
import '../styles/meal3d.css';

export default function MealScene({portion=1,onDishChange, builder=false,amounts=[1,1,1],dishIndex:externalIndex}) {
  const host=useRef(null), labels=useRef([]), lines=useRef([]);
  const [index,setIndex]=useState(externalIndex ?? 0),[active,setActive]=useState(-1),[paused,setPaused]=useState(()=>matchMedia('(prefers-reduced-motion: reduce)').matches),[turn,setTurn]=useState(0),[failed,setFailed]=useState(false);
  const state=useRef({active:-1,paused:false,portion:1,amounts:[1,1,1]});
  state.current={active,paused,portion,amounts};
  const dish=dishes[index];
  useEffect(()=>{if(externalIndex!==undefined)setIndex(externalIndex);},[externalIndex]);
  useEffect(()=>{onDishChange?.(index);},[index,onDishChange]);
  useEffect(()=>{
    const element=host.current;
    let renderer;
    try {renderer=new THREE.WebGLRenderer({alpha:true,antialias:true,powerPreference:'low-power'});} catch {setFailed(true);return;}
    setFailed(false);setTurn(0);
    renderer.setPixelRatio(Math.min(devicePixelRatio,1.5));renderer.shadowMap.enabled=true;renderer.shadowMap.type=THREE.PCFSoftShadowMap;renderer.setClearColor(0xffffff,0);renderer.outputColorSpace=THREE.SRGBColorSpace;
    element.appendChild(renderer.domElement);
    const scene=new THREE.Scene(),camera=new THREE.PerspectiveCamera(34,1,.1,40);camera.position.set(0,4.5,5.7);camera.lookAt(0,.15,0);
    scene.add(new THREE.HemisphereLight(0xffffff,0xb8c9d9,1.8));
    const light=new THREE.DirectionalLight(0xfff4df,2);light.position.set(-3,6,4);light.castShadow=true;light.shadow.mapSize.set(1024,1024);scene.add(light);
    const fill=new THREE.DirectionalLight(0xc9f6ff,1.4);fill.position.set(4,3,-3);scene.add(fill);
    const rotor=new THREE.Group();scene.add(rotor);rotor.add(createPlate());
    const food=createFood(index);food.forEach(g=>rotor.add(g));
    const shadow=new THREE.Mesh(new THREE.PlaneGeometry(12,12),new THREE.ShadowMaterial({opacity:.13}));shadow.rotation.x=-Math.PI/2;shadow.position.y=-.14;shadow.receiveShadow=true;scene.add(shadow);
    const resize=()=>{const {width,height}=element.getBoundingClientRect();renderer.setSize(width,height,false);camera.aspect=width/height;camera.updateProjectionMatrix();};const observer=new ResizeObserver(resize);observer.observe(element);resize();
    let visible=true;const intersection=new IntersectionObserver(entries=>{visible=entries[0].isIntersecting;});intersection.observe(element);
    const ray=new THREE.Raycaster(),pointer=new THREE.Vector2(),projected=new THREE.Vector3();
    let dragging=false,lastX=0,travel=0,rotations=0,previous=performance.now(),frame,lastTurn=-1,disposed=false;
    const pick=e=>{const r=element.getBoundingClientRect();pointer.set((e.clientX-r.left)/r.width*2-1,-(e.clientY-r.top)/r.height*2+1);ray.setFromCamera(pointer,camera);const hit=ray.intersectObjects(food,true)[0];setActive(hit?.object.userData.ingredient ?? -1);};
    const down=e=>{dragging=true;lastX=e.clientX;element.setPointerCapture(e.pointerId);};
    const move=e=>{if(dragging){const delta=(e.clientX-lastX)*.012;rotor.rotation.y+=delta;rotations+=Math.abs(delta);lastX=e.clientX;travel+=Math.abs(delta);setActive(-1);}else pick(e);};
    const up=e=>{if(travel<.03)pick(e);dragging=false;travel=0;};
    const leave=()=>{if(!dragging)setActive(-1);};
    element.addEventListener('pointerdown',down);element.addEventListener('pointermove',move);element.addEventListener('pointerup',up);element.addEventListener('pointercancel',up);element.addEventListener('pointerleave',leave);
    const animate=now=>{
      if(disposed)return;frame=requestAnimationFrame(animate);const dt=Math.min((now-previous)/1000,.05);previous=now;if(!visible || document.hidden)return;
      const s=state.current;
      if(!s.paused && !dragging && s.active===-1){const delta=dt*Math.PI/6;rotor.rotation.y+=delta;rotations+=delta;}
      const count=Math.min(3,Math.floor(rotations/(2*Math.PI)));if(count!==lastTurn){lastTurn=count;setTurn(count);}
      if(rotations>=6*Math.PI && !builder){setIndex(i=>(i+1)%dishes.length);return;}
      const entrance=Math.min(1,(now-start)/750),bounce=1-Math.pow(1-entrance,3);rotor.scale.setScalar(.7+.3*bounce);rotor.position.y=(1-bounce)*.45;
      food.forEach((g,i)=>{
        const selected=s.active===i,amount=builder?s.amounts[i]:1;
        g.visible=amount>0;
        const scale=(selected?1.16:1)*Math.cbrt(Math.max(.01,amount))*Math.cbrt(s.portion);
        g.scale.lerp(new THREE.Vector3(scale,scale,scale),Math.min(1,dt*9));g.position.y=THREE.MathUtils.lerp(g.position.y,g.userData.rest.y+(selected ? .22 : 0),Math.min(1,dt*9));
        g.traverse(o=>{if(o.isMesh){const color=o.material.userData.base.clone();if(!selected)color.lerp(new THREE.Color(0xe7edf0),.38);o.material.color.lerp(color,Math.min(1,dt*8));o.material.emissive.set(selected?0x102a28:0x000000);}});
        const anchor=g.userData.anchor || new THREE.Vector3(0,.3,0);g.localToWorld(projected.copy(anchor));projected.project(camera);
        const x=(projected.x*.5+.5)*100,y=(-projected.y*.5+.5)*100;
        const label=labels.current[i],line=lines.current[i];if(label)label.style.opacity=amount>0?1:0;
        if(line){const ends=[[78,22],[17,74],[14,23]];line.setAttribute('d',`M ${x} ${y} L ${ends[i][0]} ${ends[i][1]}`);line.style.opacity=amount>0?1:0;}
      });
      renderer.render(scene,camera);
    };
    const start=performance.now();frame=requestAnimationFrame(animate);
    return()=>{disposed=true;cancelAnimationFrame(frame);observer.disconnect();intersection.disconnect();for(const [type,fn] of [['pointerdown',down],['pointermove',move],['pointerup',up],['pointercancel',up],['pointerleave',leave]])element.removeEventListener(type,fn);const geometries=new Set(),materials=new Set();scene.traverse(o=>{if(o.isMesh){geometries.add(o.geometry);materials.add(o.material);}});geometries.forEach(g=>g.dispose());materials.forEach(m=>m.dispose());renderer.dispose();renderer.domElement.remove();};
  },[index,builder]);
  const total=dish.ingredients.reduce((sum,i,n)=>sum+i.mass*i.kcal/100*portion*(builder?amounts[n]:1),0);
  return <div className="meal-showcase">
    <div className="meal-heading"><span>ИНТЕРАКТИВНЫЙ 3D-ОБЕД</span><strong>{dish.name}</strong><small>{dish.note}</small></div>
    <div className="meal-stage"><div className="meal-halo"/><div ref={host} className="meal-canvas" role="img" aria-label={`Вращающаяся 3D-тарелка: ${dish.name}. Перетаскивайте для вращения; ингредиенты доступны кнопками.`}/>{failed && <div className="meal-fallback">3D недоступно в этом браузере. Состав и расчёт доступны ниже.</div>}
      <svg className="meal-arrows" viewBox="0 0 100 100" preserveAspectRatio="none" aria-hidden="true"><defs><marker id={builder?'builder-arrow':'meal-arrow'} viewBox="0 0 10 10" refX="1" refY="5" markerWidth="4" markerHeight="4" orient="auto-start-reverse"><path d="M10 0 L0 5 L10 10" fill="#0198af"/></marker></defs>{dish.ingredients.map((_,i)=><path key={i} ref={node=>lines.current[i]=node} markerStart={`url(#${builder?'builder-arrow':'meal-arrow'})`} className={active===i?'is-active':''}/>)}</svg>
      {dish.ingredients.map((ingredient,i)=><button hidden={builder && amounts[i]===0} key={ingredient.name} ref={node=>labels.current[i]=node} className={`meal-label meal-label-${i} ${active===i?'is-active':''}`} onMouseEnter={()=>setActive(i)} onMouseLeave={()=>setActive(-1)} onFocus={()=>setActive(i)} onBlur={()=>setActive(-1)} onClick={()=>setActive(i)}><span>{ingredient.name}</span><strong>{Math.round(ingredient.mass*ingredient.kcal/100*portion*(builder?amounts[i]:1))} <small>ккал</small></strong><em>{Math.round(ingredient.mass*portion*(builder?amounts[i]:1))} г</em></button>)}
      <div className="meal-total" aria-live="polite"><span>Вся тарелка</span><strong>{Math.round(total)} <small>ккал</small></strong></div>
    </div>
    <div className="meal-toolbar"><button onClick={()=>setPaused(!paused)} aria-label={paused?'Включить вращение':'Остановить вращение'}>{paused?'▶ Вращать':'Ⅱ Пауза'}</button><span>{builder?'Перетащите тарелку':`Оборот ${Math.min(turn+1,3)} / 3 · затем новое блюдо`}</span></div>
    {!builder && <div className="meal-tabs" role="group" aria-label="Выбрать блюдо">{dishes.map((d,i)=><button key={d.name} aria-pressed={index===i} onClick={()=>setIndex(i)}>{d.name}</button>)}</div>}
    <p className="meal-hint">Наведите на ингредиент — он оживёт. Потяните тарелку — она повернётся.</p>
  </div>;
}
