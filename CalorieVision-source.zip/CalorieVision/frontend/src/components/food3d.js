import * as THREE from 'three';

export const dishes = [
  {name:'Курица с рисом',note:'Обед между парами',ingredients:[{name:'Куриная грудка',mass:150,kcal:165,protein:31,fat:3.6,carbs:0},{name:'Рис отварной',mass:150,kcal:130,protein:2.7,fat:.3,carbs:28},{name:'Овощи',mass:100,kcal:35,protein:1.5,fat:.3,carbs:6}]},
  {name:'Паста с томатами',note:'Маленькое путешествие в Италию',ingredients:[{name:'Паста отварная',mass:180,kcal:158,protein:5.8,fat:.9,carbs:30.9},{name:'Томатный соус',mass:80,kcal:60,protein:1.5,fat:2,carbs:9},{name:'Пармезан',mass:15,kcal:431,protein:38,fat:29,carbs:4}]},
  {name:'Пицца «Маргарита»',note:'Классика на вашей тарелке',ingredients:[{name:'Основа пиццы',mass:140,kcal:260,protein:8,fat:4,carbs:48},{name:'Моцарелла',mass:60,kcal:250,protein:18,fat:19,carbs:2},{name:'Томаты и базилик',mass:80,kcal:25,protein:1,fat:.3,carbs:4}]},
];

const sphere = new THREE.SphereGeometry(1,18,12);
const grain = new THREE.SphereGeometry(1,8,6);
function material(color) { const m=new THREE.MeshStandardMaterial({color,roughness:.47,metalness:.02});m.userData.base=new THREE.Color(color);return m; }
function mesh(group,geometry,color,position=[0,0,0],scale=[1,1,1]) {const m=new THREE.Mesh(geometry,material(color));m.position.set(...position);m.scale.set(...scale);m.castShadow=true;m.receiveShadow=true;group.add(m);return m;}
function ball(group,color,pos,scale){return mesh(group,sphere,color,pos,scale);}
function leaf(group,pos,angle=0){const l=ball(group,0x438d48,pos,[.23,.055,.11]);l.rotation.y=angle;return l;}
function tomato(group,x,z,size=.17){ball(group,0xe64834,[x,.36,z],[size,size*.9,size]);ball(group,0xffa279,[x-.045,.43,z+.055],[.045,.017,.02]);leaf(group,[x,.36+size,z],.5);}
function cucumber(group,x,z){const c=mesh(group,new THREE.CylinderGeometry(.17,.17,.055,22),0x388b49,[x,.3,z]);mesh(c,new THREE.CylinderGeometry(.14,.14,.061,22),0xc4e889);mesh(c,new THREE.CylinderGeometry(.08,.08,.066,16),0xf1f2c2);}
function tube(group,points,radius,color){const curve=new THREE.CatmullRomCurve3(points.map(p=>new THREE.Vector3(...p)));return mesh(group,new THREE.TubeGeometry(curve,12,radius,7,false),color);}

export function createPlate() {
  const g=new THREE.Group();
  const points=[[0,.03],[1.65,.03],[1.86,.08],[2,.18],[2.09,.22],[2.12,.19],[2.06,.1],[1.92,-.02],[.25,-.08],[0,-.08]].map(p=>new THREE.Vector2(...p));
  const plate=mesh(g,new THREE.LatheGeometry(points,72),0xfafcff);
  plate.material.roughness=.2;
  mesh(g,new THREE.TorusGeometry(1.96,.018,8,72),0xb8d6dc,[0,.155,0]).rotation.x=Math.PI/2;
  return g;
}

export function createFood(index) {
  const groups=[0,1,2].map(i=>{const g=new THREE.Group();g.userData.ingredient=i;return g;});
  if(index===0){
    const [chicken,rice,veg]=groups;
    chicken.position.set(.55,.12,-.35);
    const breast=ball(chicken,0xe8a348,[0,.26,0],[.68,.27,.48]);breast.rotation.y=.3;
    for(let i=0;i<6;i++){const stripe=mesh(chicken,new THREE.CapsuleGeometry(.018,.6,3,6),0x87532d,[-.4+i*.145,.49,-.04],[1,1,1]);stripe.rotation.z=Math.PI/2;stripe.rotation.y=-.5;stripe.position.y=.48-Math.abs(i-2.5)*.025;}
    rice.position.set(-.57,.1,.42);
    ball(rice,0xd9c9a1,[0,.15,0],[.66,.16,.55]);
    for(let i=0;i<85;i++){const a=i*2.399,r=Math.sqrt(i/85)*.6;const p=ball(rice,i%3?0xfff0ce:0xe6d4a4,[Math.cos(a)*r,.19+.1*(1-r/.7),Math.sin(a)*r*.85],[.065,.028,.025]);p.rotation.y=i*1.1;}
    veg.position.set(-.55,0,-.7);
    for(let i=0;i<6;i++)leaf(veg,[Math.cos(i)*.37,.27,Math.sin(i)*.26],i);
    tomato(veg,-.25,.02);tomato(veg,.13,-.13);tomato(veg,.31,.13);
    cucumber(veg,.32,.45);cucumber(veg,.07,.56);
  }else if(index===1){
    const [pasta,sauce,cheese]=groups;
    for(let i=0;i<45;i++){const a=i*2.399,r=Math.sqrt(i/45)*1.1,x=Math.cos(a)*r,z=Math.sin(a)*r;const noodle=tube(pasta,[[x-.16,.2,z-.14],[x-.08,.28+(i%4)*.045,z],[x+.11,.23,z+.12],[x+.17,.2,z+.15]],.045,i%3?0xf2c475:0xe5a748);noodle.rotation.y=i*.8;}
    for(let i=0;i<11;i++){const a=i*2.39,r=.7*Math.sqrt(i/11);ball(sauce,0xcc4934,[Math.cos(a)*r,.31,Math.sin(a)*r],[.22,.06,.18]);}
    tomato(sauce,.65,-.42,.19);tomato(sauce,-.73,.15,.16);leaf(sauce,[.35,.5,.3],.8);leaf(sauce,[.14,.48,.18],-.5);
    for(let i=0;i<22;i++){const a=i*2.399,r=Math.sqrt(i/22)*.84;const flake=mesh(cheese,new THREE.BoxGeometry(.13,.018,.06),0xffedb8,[Math.cos(a)*r,.46+(i%3)*.02,Math.sin(a)*r]);flake.rotation.y=i*1.3;}
    pasta.userData.anchor=new THREE.Vector3(-.6,.3,.45);sauce.userData.anchor=new THREE.Vector3(.6,.5,-.4);cheese.userData.anchor=new THREE.Vector3(.1,.5,.5);
  }else{
    const [base,cheese,tomatoes]=groups;
    mesh(base,new THREE.CylinderGeometry(1.35,1.36,.13,64),0xd99743,[0,.16,0]);
    mesh(base,new THREE.TorusGeometry(1.23,.12,12,64),0xe8b064,[0,.25,0]).rotation.x=Math.PI/2;
    mesh(cheese,new THREE.CylinderGeometry(1.18,1.18,.03,64),0xeab85d,[0,.25,0]);
    for(let i=0;i<12;i++){const a=i*2.399,r=Math.sqrt(i/12)*1;const mozz=ball(cheese,0xfff2cb,[Math.cos(a)*r,.31,Math.sin(a)*r],[.24,.035,.18]);mozz.rotation.y=i*.7;}
    for(let i=0;i<7;i++){const a=i*2.399,r=.75*Math.sqrt((i+1)/7),x=Math.cos(a)*r,z=Math.sin(a)*r;mesh(tomatoes,new THREE.CylinderGeometry(.19,.19,.035,24),0xd44130,[x,.3,z]);mesh(tomatoes,new THREE.TorusGeometry(.13,.015,6,20),0xf3975b,[x,.325,z]).rotation.x=Math.PI/2;}
    for(let i=0;i<5;i++)leaf(tomatoes,[Math.cos(i*1.3)*.8,.36,Math.sin(i*1.3)*.8],i);
    base.userData.anchor=new THREE.Vector3(-1.1,.25,.35);cheese.userData.anchor=new THREE.Vector3(.7,.35,-.5);tomatoes.userData.anchor=new THREE.Vector3(.2,.4,.6);
  }
  groups.forEach(g=>{g.userData.rest=g.position.clone();g.traverse(o=>{if(o.isMesh)o.userData.ingredient=g.userData.ingredient;});});
  return groups;
}
