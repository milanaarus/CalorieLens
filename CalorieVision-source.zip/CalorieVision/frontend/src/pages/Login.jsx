import Icon from '../components/Icon';
import { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { login, register } from '../api/client';
import '../styles/auth.css';

const Login = () => {
  const navigate = useNavigate();
  const [isRegister, setIsRegister] = useState(false);
  const [form, setForm] = useState({ email: '', password: '', name: '' });
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    try {
      let result;
      if (isRegister) {
        result = await register(form);
      } else {
        result = await login({ email: form.email, password: form.password });
      }

      if (result.success) {
        localStorage.setItem('token', result.token);
        localStorage.setItem('user', JSON.stringify(result.user));
        navigate('/dashboard');
      }
    } catch (err) {
      const detail = err.response?.data?.detail;
      setError(typeof detail==='string' ? detail : Array.isArray(detail) ? detail.map(x=>x.msg.replace('Value error, ', '')).join('; ') : 'Не удалось войти. Проверьте соединение и повторите.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="auth-page">
      <div className="auth-card">
        <div className="auth-logo">CalorieVision</div>
        <h2>{isRegister ? 'Регистрация' : 'Вход'}</h2>
        <p className="auth-subtitle">
          {isRegister
            ? 'Создайте аккаунт — подойдёт почта любого домена'
            : 'Войдите, чтобы продолжить'}
        </p>

        {error && <div className="auth-error">{error}</div>}

        <form onSubmit={handleSubmit}>
          {isRegister && (
            <div className="form-group">
              <label>Имя</label>
              <input
                type="text"
                value={form.name}
                onChange={(e) => setForm({ ...form, name: e.target.value })}
                required
              />
            </div>
          )}

          <div className="form-group">
            <label htmlFor="login-email">Электронная почта</label>
            <input
              id="login-email"
              autoComplete="email"
              placeholder="name@example.com"
              type="email"
              value={form.email}
              onChange={(e) => setForm({ ...form, email: e.target.value })}
              required
            />
          </div>

          <div className="form-group">
            <label>Пароль</label>
            <input
              type="password"
              value={form.password}
              onChange={(e) => setForm({ ...form, password: e.target.value })}
              required
              minLength={4}
            />
          </div>

          <button type="submit" className="btn btn-primary" disabled={loading}>
            {loading ? 'Загрузка…' : isRegister ? 'Создать аккаунт' : 'Войти'}
          </button>
        </form>

        <div className="auth-switch">
          {isRegister ? (
            <>
              Уже есть аккаунт?{' '}
              <button onClick={() => setIsRegister(false)}>Войти</button>
            </>
          ) : (
            <>
              Нет аккаунта?{' '}
              <button onClick={() => setIsRegister(true)}>Зарегистрироваться</button>
            </>
          )}
        </div>
      </div>
    </div>
  );
};

export default Login;
