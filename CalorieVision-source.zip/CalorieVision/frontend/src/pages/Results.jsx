import {PORTIONS, PREPARATIONS, foodRule, candidateItem} from '../config/portions';
import { useState, useEffect } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { saveMeal, searchFoods, getFoodCatalog } from '../api/client';
import {emptyNutrition, completeValues, hasNutrition, prepareItem, mealTotals} from '../utils/nutrition';
import {readMealDraft, writeMealDraft, clearMealDraft} from '../utils/mealDraft';
import '../styles/results.css';
import '../styles/review.css';

const blankItem = () => ({name:'', estimated_mass:100, confidence:0, nutrition_missing:true,nutrition_per_100g:emptyNutrition()});
export default function Results() {
  const location = useLocation();
  const navigate = useNavigate();
  const [scan, setScan] = useState(location.state?.scan);
  const [pendingDraft, setPendingDraft] = useState(()=>readMealDraft());
  const [draftStatus, setDraftStatus] = useState('');
  const [items, setItems] = useState(()=>(scan?.items || []).map(prepareItem));
  const [mealType, setMealType] = useState(scan?.meal_type || 'lunch');
  const [busy, setBusy] = useState(false);
  const [saved, setSaved] = useState(false);
  const [error, setError] = useState('');
  const [searching, setSearching] = useState(false);
  const [query, setQuery] = useState('');
  const [candidate, setCandidate] = useState(null);
  const [choices, setChoices] = useState([]);
  const [replaceIndex, setReplaceIndex] = useState(null);
  const [catalog, setCatalog] = useState([]);
  const [redOnly, setRedOnly] = useState(false);
  const [online, setOnline] = useState(true);
  useEffect(() => { getFoodCatalog().then(data => setCatalog(data.foods)).catch(() => {}); }, []);
  useEffect(() => {
    if (saved || pendingDraft) return;
    const ok = writeMealDraft(items, mealType);
    setDraftStatus(ok ? (items.length ? 'Черновик сохранён в этом браузере. Фотография в черновик не входит.' : '') : 'Не удалось сохранить черновик в браузере. Не закрывайте страницу до сохранения в дневник.');
  }, [items, mealType, saved, pendingDraft]);
  const restoreDraft = () => {
    setItems(pendingDraft.items.map(prepareItem)); setMealType(pendingDraft.mealType);
    setScan({manual:true}); setPendingDraft(null); setError('');
  };
  const discardDraft = () => {
    if (!clearMealDraft()) { setError('Не удалось удалить черновик. Проверьте доступ к хранилищу браузера.'); return; }
    setPendingDraft(null);
  };
  const lookup = async (value = query) => {
    if(value.trim().length<2 || searching) return;
    setSearching(true); setError(''); setCandidate(null); setChoices([]);
    try {
      const data = await searchFoods(value.trim(), online);
      if(data.found) { const found = data.products || [data.product]; setChoices(found); if(found.length === 1) setCandidate(found[0]); }
      else setError(online ? 'Не найдено подходящих данных. Введите КБЖУ с упаковки или выберите продукт из встроенного справочника.' : 'Во встроенном справочнике этого продукта пока нет. Можно включить дополнительный онлайн-поиск или ввести КБЖУ с упаковки.');
    } catch(err) { setError(err.response?.data?.detail || 'Поиск недоступен. Можно использовать встроенный справочник или ввести данные вручную.'); }
    finally { setSearching(false); }
  };
  const addCandidate = () => {
    const entry = candidateItem(candidate, replaceIndex === null ? null : items[replaceIndex]);
    setItems(replaceIndex === null ? [...items,entry] : items.map((item,i)=>i===replaceIndex ? entry : item));
    setReplaceIndex(null);
    setCandidate(null); setChoices([]); setQuery('');
  };
  const update = (index, field, value) => setItems(items.map((item,i)=> i === index ? {...item,[field]:value,...(field==='estimated_mass' ? {mass_edited:true,mass_confirmed:false} : {})} : item));
  const changePreparation = (index,value) => setItems(items.map((item,i)=>i===index ? {...item,preparation:value,nutrition_missing:true,nutrition_per_100g:emptyNutrition(),mass_confirmed:false,source:'Приготовление изменено — подберите соответствующие КБЖУ',source_url:null} : item));
  const updateNutrition = (index,key,value) => setItems(items.map((item,i)=>{
    if(i!==index) return item;
    const nutrition={...item.nutrition_per_100g,[key]:value};
    return {...item,nutrition_per_100g:nutrition,nutrition_missing:!completeValues(nutrition),source:'КБЖУ введены вручную — проверьте источник',source_url:null};
  }));
  const missingNutrition = items.some(item=>!hasNutrition(item));
  const totals = mealTotals(items);
  const save = async e => {
    e.preventDefault();
    if (busy || saved) return;
    if (items.some(item=>!item.preparation)) {setError('Уточните приготовление каждого продукта и подберите соответствующие КБЖУ.');return;}
    if (items.some(item=>(item.confidence>0 || item.portion_category) && !item.mass_confirmed)) {setError('Проверьте состав и приготовление, укажите массу и подтвердите каждый распознанный продукт.');return;}
    if (missingNutrition) {
      setError('Заполните все четыре значения КБЖУ для каждого продукта или выберите запись из справочника. Если значение равно нулю, укажите 0 явно.'); return;
    }
    setBusy(true); setError('');
    try { await saveMeal({meal_type:mealType,items:items.map(item=>({...item,name:`${item.name.trim()} (${PREPARATIONS[item.preparation]})`,estimated_mass:Number(item.estimated_mass)}))}); clearMealDraft(); setPendingDraft(null); setDraftStatus(''); setSaved(true); }
    catch(err) { setError(typeof err.response?.data?.detail==='string' ? err.response.data.detail : 'Не удалось сохранить. Проверьте данные и повторите.'); }
    finally { setBusy(false); }
  };
  return <div className="results-page"><div className="results-header"><h1>{saved ? 'Приём пищи в дневнике' : 'Проверьте приём пищи'}</h1><p>{saved ? 'Результат сохранён. Он доступен в истории и недельной статистике.' : 'Уточните продукты и массу порций перед сохранением.'}</p></div>
    {!saved && pendingDraft && <section className="card draft-prompt" aria-label="Незавершённый приём пищи">
      <h2>У вас есть черновик</h2><p>Можно восстановить продукты, массу, КБЖУ и тип приёма пищи. Фото потребуется загрузить заново. Восстановление заменит текущий состав; запись в дневнике не появится.</p>
      <div className="results-actions"><button type="button" className="btn btn-primary" onClick={restoreDraft}>Восстановить черновик</button><button type="button" className="btn btn-secondary" onClick={discardDraft}>Удалить черновик</button></div>
    </section>}
    {!saved && draftStatus && <p role="status" className="review-help">{draftStatus}</p>}
    {!saved && <p className="review-notice">{scan?.manual ? 'Укажите продукты, массу и КБЖУ на 100 г. Запись сохранится только после нажатия «Сохранить в дневник».' : <>Модель находит видимые продукты и может ошибаться или пропускать ингредиенты. Начальная масса задаётся по справочнику порций — это не измерение веса. Уточните приготовление, общую массу каждого продукта, масло и соусы. Оценка модели не означает точность калорий.</>}</p>}
    <p className="review-help">{!items.length ? 'Добавьте продукт для расчёта.' : missingNutrition ? "Расчёт неполный: найдите КБЖУ для продуктов без данных. Ноль не означает отсутствие калорий." : items.some(item=>(item.confidence>0 || item.portion_category) && !item.mass_confirmed) ? "Предварительный итог: подтвердите состав и массу порций." : "Итог по указанным порциям."}</p><div className="card review-summary" aria-live="polite"><strong>{totals ? Math.round(totals.calories) : '—'} <small>ккал</small></strong><span>Белки {totals ? Math.round(totals.protein) : '—'} г</span><span>Жиры {totals ? Math.round(totals.fat) : '—'} г</span><span>Углеводы {totals ? Math.round(totals.carbs) : '—'} г</span></div>
    {scan?.preview && <section className="card detected-photo-card"><h2>{scan.manual ? 'Фотография блюда' : 'Что найдено на фото'}</h2><div className="detected-photo"><img src={scan.preview} alt={scan.manual ? 'Фотография блюда для ручного ввода' : 'Фотография блюда с областями распознавания'}/>{(scan.items || []).flatMap((item,index)=>(item.boxes || []).map((box,j)=><div key={`${index}-${j}`} className="detected-box" style={{left:`${box[0]*100}%`,top:`${box[1]*100}%`,width:`${(box[2]-box[0])*100}%`,height:`${(box[3]-box[1])*100}%`}}><span>{index+1}. {item.name}</span></div>))}</div><p>{scan.manual ? 'Добавьте продукты из справочника или введите состав и КБЖУ вручную. Фото служит подсказкой; масса указывается вами.' : 'Рамки показывают предложения модели. Проверьте также продукты вне рамок.'}</p></section>}
    <form onSubmit={save} onInvalid={()=>setError('Заполните название, массу и все четыре значения КБЖУ. Нулевые значения укажите явно.')}><fieldset disabled={busy || saved} className="review-fieldset">
      <label className="review-meal">Приём пищи <select value={mealType} onChange={e=>setMealType(e.target.value)}>{[['breakfast','Завтрак'],['lunch','Обед'],['dinner','Ужин'],['snack','Перекус']].map(([v,l])=><option key={v} value={v}>{l}</option>)}</select></label>
      {items.map((item,index)=><article className="card review-item" key={index}><div className="review-item-top"><span>Продукт {index+1}{item.recognition_method==='cloud' ? ' · предложено облачной моделью, проверьте' : item.confidence>0 ? ` · ${Math.round(item.confidence*100)}% оценка модели` : ' · введён вручную'}</span><button type="button" className="review-remove" onClick={()=>{setReplaceIndex(null);setItems(items.filter((_,i)=>i!==index));}} aria-label={`Удалить продукт ${index+1}`}>Удалить</button></div><div className="review-inputs"><label>Название<input required maxLength={255} value={item.name} onChange={e=>setItems(items.map((entry,i)=>i===index ? {...entry,name:e.target.value,nutrition_missing:true,mass_confirmed:false,preparation:'',portion_category:null,source:'Название изменено — проверьте КБЖУ',source_url:null,nutrition_per_100g:emptyNutrition()} : entry))}/></label><label>Приготовление<select required value={item.preparation || ''} onChange={e=>changePreparation(index,e.target.value)}><option value="">Уточните приготовление</option>{Object.entries(PREPARATIONS).map(([v,l])=><option key={v} value={v}>{l}</option>)}</select></label><label>Масса, г<input type="number" required min="1" max="3000" step="1" value={item.estimated_mass ?? ''} onChange={e=>update(index,'estimated_mass',e.target.value)}/></label>{[['calories','Ккал / 100 г',1000],['protein','Белки / 100 г',100],['fat','Жиры / 100 г',100],['carbs','Углеводы / 100 г',100]].map(([k,label,max])=><label key={k}>{label}<input type="number" required min="0" max={max} step="any" placeholder="Нет данных" value={item.nutrition_per_100g?.[k] ?? ''} onChange={e=>updateNutrition(index,k,e.target.value)}/></label>)}</div><p className="portion-hint">Стандартная порция. Вес по фото не определён — уточните перед сохранением.<br/>{PORTIONS[item.portion_category || foodRule(item.name).category].hint}</p><button type="button" className="btn btn-secondary" onClick={()=>{setReplaceIndex(index);setQuery('');setCandidate(null);setChoices([]);}}>Заменить продукт из справочника</button>{!hasNutrition(item) && <button type="button" className="btn btn-primary" disabled={searching} onClick={()=>{setReplaceIndex(index);setQuery(item.name);lookup(item.name);document.getElementById('food-query')?.scrollIntoView({behavior:'smooth',block:'center'});}}>Найти КБЖУ {online ? 'онлайн' : 'в справочнике'}</button>}{(item.confidence>0 || item.portion_category) && <label className="confirm-portion"><input type="checkbox" checked={Boolean(item.mass_confirmed)} onChange={e=>update(index,'mass_confirmed',e.target.checked)}/> Состав, приготовление и общая масса этого продукта проверены</label>}<p>{item.source}{item.source_url && <> · <a href={item.source_url} target="_blank" rel="noreferrer">Источник данных</a></>}{!hasNutrition(item) ? " · заполните все значения КБЖУ или выберите продукт из справочника" : ""}</p><p className="review-item-total">{hasNutrition(item) && Number(item.estimated_mass)>0 ? <>В порции: {['calories','protein','fat','carbs'].map((k,i)=>`${['Ккал','Б','Ж','У'][i]} ${Math.round(Number(item.nutrition_per_100g[k])*Number(item.estimated_mass)/100)}${i ? ' г' : ''}`).join(' · ')}</> : 'В порции: нет расчёта — заполните КБЖУ и массу'}</p></article>)}
      <button type="button" className="btn btn-secondary" onClick={()=>setItems([...items,blankItem()])} disabled={items.length>=50}>+ Добавить продукт или соус</button>
      <section className="card student-food-catalog" aria-label="Каталог продуктов">
        <h2>{replaceIndex === null ? "Что было в вашей тарелке?" : `Выберите замену для продукта ${replaceIndex+1}`}</h2>{replaceIndex !== null && <button type="button" className="btn btn-secondary" onClick={()=>setReplaceIndex(null)}>Отменить замену</button>}
        <p>{catalog.filter(f=>f.local).length} продуктов с готовыми КБЖУ без внешних сервисов. Значения справочные, на 100 г съедобной части. Выбирайте правильный способ приготовления.</p>
        <label><input type="checkbox" checked={online} onChange={e=>{setOnline(e.target.checked); setCandidate(null);}}/> Дополнительный онлайн-поиск: {catalog.length} названий, результаты могут отсутствовать</label>
        <label>Фильтр каталога<input value={query} onChange={e=>setQuery(e.target.value)} placeholder="Гречка, курица, помидор…" maxLength={120}/></label>
        <label><input type="checkbox" checked={redOnly} onChange={e=>setRedOnly(e.target.checked)}/> Красные продукты и блюда</label>
        <div className="catalog-options">{catalog.filter(f=>(online || f.local) && (!redOnly || f.red_focus) && f.name.toLocaleLowerCase('ru').replaceAll('ё','е').includes(query.toLocaleLowerCase('ru').replaceAll('ё','е'))).slice(0,24).map(food=><button type="button" className="btn btn-secondary" key={food.id} disabled={searching} onClick={()=>{setQuery(food.name); lookup(food.name);}}>{food.name}</button>)}</div>
        <p>Показаны первые 24 совпадения. Выберите продукт, проверьте карточку ниже и добавьте его в состав. Для сложного блюда укажите ингредиенты отдельно; масло и соусы добавляются отдельно.</p>
      </section>
      <div className="card nutrition-search"><label htmlFor="food-query">Найти КБЖУ по названию продукта</label><div><input id="food-query" maxLength={120} value={query} onChange={e=>setQuery(e.target.value)} placeholder="Например: банан или название с упаковки"/><button type="button" className="btn btn-secondary" disabled={searching || query.trim().length<2} onClick={()=>lookup()}>{searching?'Ищем…':'Найти'}</button></div>{choices.length>0 && <div className="nutrition-choices"><p>Выберите подходящий товар. Значения указаны на 100 г.</p>{choices.map((choice,i)=><button type="button" className="btn btn-secondary" key={choice.source_url || i} aria-pressed={candidate===choice} onClick={()=>setCandidate(choice)}>{choice.name}{choice.brands ? ` · ${choice.brands}` : ''} · {Math.round(choice.calories_per_100g)} ккал{choice.cached ? ' · сохранённые данные' : ''}</button>)}</div>}{candidate && <article><strong>{candidate.name}</strong><p>{candidate.calories_per_100g} ккал / 100 г · {candidate.source}{candidate.cached?' · из кэша':''}</p><p>Проверьте название, производителя и приготовление. Это данные конкретного товара, они могут отличаться от блюда на фото.</p>{candidate.source_url && <a href={candidate.source_url} target="_blank" rel="noreferrer">Открыть источник ↗</a>}<button type="button" className="btn btn-secondary" onClick={addCandidate} disabled={items.length>=50}>{replaceIndex === null ? "Добавить найденный продукт" : "Заменить выбранный продукт"}</button></article>}</div>
      <p className="review-help">Для ручного ввода возьмите данные на 100 г с упаковки или технологической карты. Справочные значения могут отличаться от вашего продукта. Общий итог зависит от состава и указанной массы.</p>
      {error && <p role="alert" className="review-error">{error}</p>}
      {!saved && <button className="btn btn-primary" type="submit" disabled={busy || !items.length}>{busy ? 'Сохраняем…' : 'Сохранить в дневник'}</button>}
    </fieldset></form>
    <div className="results-actions">{saved && <button className="btn btn-primary" onClick={()=>navigate('/history')}>Открыть историю</button>}<button className="btn btn-secondary" onClick={()=>navigate('/scan')}>Сканировать ещё</button><button className="btn btn-secondary" onClick={()=>navigate('/dashboard')}>Обзор недели</button></div>
  </div>;
}
