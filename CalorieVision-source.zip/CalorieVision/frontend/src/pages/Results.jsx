import { useState } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { saveMeal, searchFoods } from '../api/client';
import '../styles/results.css';
import '../styles/review.css';

const blankItem = () => ({name:'', estimated_mass:100, confidence:0, nutrition_per_100g:{calories:0,protein:0,fat:0,carbs:0}});
export default function Results() {
  const location = useLocation();
  const navigate = useNavigate();
  const scan = location.state?.scan;
  const [items, setItems] = useState(scan?.items || [blankItem()]);
  const [mealType, setMealType] = useState(scan?.meal_type || 'lunch');
  const [busy, setBusy] = useState(false);
  const [saved, setSaved] = useState(false);
  const [error, setError] = useState('');
  const [searching, setSearching] = useState(false);
  const [query, setQuery] = useState('');
  const [candidate, setCandidate] = useState(null);
  const lookup = async () => {
    if(query.trim().length<2 || searching) return;
    setSearching(true); setError(''); setCandidate(null);
    try {
      const data = await searchFoods(query.trim());
      if(data.found) setCandidate(data.product);
      else setError('Подходящий продукт не найден или внешний сервис временно недоступен. Уточните запрос или введите данные с упаковки.');
    } catch { setError('Поиск недоступен. Можно ввести данные вручную.'); }
    finally { setSearching(false); }
  };
  const addCandidate = () => {
    setItems([...items,{name:candidate.name,estimated_mass:100,confidence:0,source:candidate.source,nutrition_per_100g:{calories:candidate.calories_per_100g,protein:candidate.protein_per_100g,fat:candidate.fat_per_100g,carbs:candidate.carbs_per_100g}}]);
    setCandidate(null);
  };
  const update = (index, field, value) => setItems(items.map((item,i)=> i === index ? {...item,[field]:value} : item));
  const totals = items.reduce((t,item)=>{ for(const k of Object.keys(t)) t[k] += Number(item.nutrition_per_100g?.[k] || 0)*Number(item.estimated_mass || 0)/100; return t; }, {calories:0,protein:0,fat:0,carbs:0});
  const save = async e => {
    e.preventDefault();
    if (busy || saved) return;
    setBusy(true); setError('');
    try { await saveMeal({meal_type:mealType,items:items.map(item=>({...item,name:item.name.trim(),estimated_mass:Number(item.estimated_mass)}))}); setSaved(true); }
    catch(err) { setError(typeof err.response?.data?.detail==='string' ? err.response.data.detail : 'Не удалось сохранить. Проверьте данные и повторите.'); }
    finally { setBusy(false); }
  };
  return <div className="results-page"><div className="results-header"><h1>{saved ? 'Обед в дневнике' : 'Проверьте ваш обед'}</h1><p>{saved ? 'Результат сохранён. Он доступен в истории и недельной статистике.' : 'Уточните продукты и массу порций перед сохранением.'}</p></div>
    {!saved && <p className="review-notice">Фото даёт предварительную оценку. Вес порции нужно уточнить, а масло, соусы и пропущенные продукты — добавить вручную. Процент уверенности относится к распознаванию продукта.</p>}
    <div className="card review-summary" aria-live="polite"><strong>{Math.round(totals.calories)} <small>ккал</small></strong><span>Белки {Math.round(totals.protein)} г</span><span>Жиры {Math.round(totals.fat)} г</span><span>Углеводы {Math.round(totals.carbs)} г</span></div>
    <form onSubmit={save}><fieldset disabled={busy || saved} className="review-fieldset">
      <label className="review-meal">Приём пищи <select value={mealType} onChange={e=>setMealType(e.target.value)}>{[['breakfast','Завтрак'],['lunch','Обед'],['dinner','Ужин'],['snack','Перекус']].map(([v,l])=><option key={v} value={v}>{l}</option>)}</select></label>
      {items.map((item,index)=><article className="card review-item" key={index}><div className="review-item-top"><span>Продукт {index+1}{item.confidence>0 ? ` · ${Math.round(item.confidence*100)}% уверенность модели` : ' · введён вручную'}</span><button type="button" className="review-remove" onClick={()=>setItems(items.filter((_,i)=>i!==index))} aria-label={`Удалить продукт ${index+1}`}>Удалить</button></div><div className="review-inputs"><label>Название<input required maxLength={255} value={item.name} onChange={e=>update(index,'name',e.target.value)}/></label><label>Масса, г<input type="number" required min="1" max="3000" step="1" value={item.estimated_mass} onChange={e=>update(index,'estimated_mass',e.target.value)}/></label>{[['calories','Ккал / 100 г',1000],['protein','Белки / 100 г',100],['fat','Жиры / 100 г',100],['carbs','Углеводы / 100 г',100]].map(([k,label,max])=><label key={k}>{label}<input type="number" required min="0" max={max} step="0.1" value={item.nutrition_per_100g?.[k] ?? 0} onChange={e=>update(index,'nutrition_per_100g',{...item.nutrition_per_100g,[k]:Number(e.target.value)})}/></label>)}</div><p className="review-item-total">В порции: {Math.round(Number(item.nutrition_per_100g?.calories || 0)*Number(item.estimated_mass || 0)/100)} ккал</p></article>)}
      <button type="button" className="btn btn-secondary" onClick={()=>setItems([...items,blankItem()])} disabled={items.length>=50}>+ Добавить продукт или соус</button>
      <div className="card nutrition-search"><label htmlFor="food-query">Найти данные о продукте</label><div><input id="food-query" maxLength={120} value={query} onChange={e=>setQuery(e.target.value)} placeholder="Например: банан или название с упаковки"/><button type="button" className="btn btn-secondary" disabled={searching || query.trim().length<2} onClick={lookup}>{searching?'Ищем…':'Найти'}</button></div>{candidate && <article><strong>{candidate.name}</strong><p>{candidate.calories_per_100g} ккал / 100 г · {candidate.source}{candidate.cached?' · из кэша':''}</p><p>Проверьте, что найден именно ваш продукт и способ приготовления.</p>{candidate.source_url && <a href={candidate.source_url} target="_blank" rel="noreferrer">Открыть источник ↗</a>}<button type="button" className="btn btn-secondary" onClick={addCandidate} disabled={items.length>=50}>Добавить найденный продукт</button></article>}</div>
      <p className="review-help">Для ручного ввода возьмите данные на 100 г с упаковки или технологической карты. Нулевые значения означают отсутствие данных: заполните их перед сохранением.</p>
      {error && <p role="alert" className="review-error">{error}</p>}
      {!saved && <button className="btn btn-primary" type="submit" disabled={busy || !items.length}>{busy ? 'Сохраняем…' : 'Сохранить в дневник'}</button>}
    </fieldset></form>
    <div className="results-actions">{saved && <button className="btn btn-primary" onClick={()=>navigate('/history')}>Открыть историю</button>}<button className="btn btn-secondary" onClick={()=>navigate('/scan')}>Сканировать ещё</button><button className="btn btn-secondary" onClick={()=>navigate('/dashboard')}>Обзор недели</button></div>
  </div>;
}
