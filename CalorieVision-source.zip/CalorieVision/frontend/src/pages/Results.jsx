import { useState, useEffect } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { saveMeal, searchFoods, getFoodCatalog } from '../api/client';
import '../styles/results.css';
import '../styles/review.css';

const blankItem = () => ({name:'', estimated_mass:100, confidence:0, nutrition_per_100g:{calories:0,protein:0,fat:0,carbs:0}});
export default function Results() {
  const location = useLocation();
  const navigate = useNavigate();
  const scan = location.state?.scan;
  const [items, setItems] = useState(scan?.items || []);
  const [mealType, setMealType] = useState(scan?.meal_type || 'lunch');
  const [busy, setBusy] = useState(false);
  const [saved, setSaved] = useState(false);
  const [error, setError] = useState('');
  const [searching, setSearching] = useState(false);
  const [query, setQuery] = useState('');
  const [candidate, setCandidate] = useState(null);
  const [replaceIndex, setReplaceIndex] = useState(null);
  const [catalog, setCatalog] = useState([]);
  const [redOnly, setRedOnly] = useState(false);
  const [online, setOnline] = useState(false);
  useEffect(() => { getFoodCatalog().then(data => setCatalog(data.foods)).catch(() => {}); }, []);
  const lookup = async (value = query) => {
    if(value.trim().length<2 || searching) return;
    setSearching(true); setError(''); setCandidate(null);
    try {
      const data = await searchFoods(value.trim(), online);
      if(data.found) setCandidate(data.product);
      else setError(online ? 'Не найдено подходящих данных. Введите КБЖУ с упаковки или выберите продукт из встроенного справочника.' : 'Во встроенном справочнике этого продукта пока нет. Можно включить дополнительный онлайн-поиск или ввести КБЖУ с упаковки.');
    } catch { setError('Поиск недоступен. Можно ввести данные вручную.'); }
    finally { setSearching(false); }
  };
  const addCandidate = () => {
    const entry = {name:candidate.name,estimated_mass:replaceIndex === null ? 100 : items[replaceIndex].estimated_mass,confidence:0,mass_confirmed:false,source:candidate.source,source_url:candidate.source_url,nutrition_per_100g:{calories:candidate.calories_per_100g,protein:candidate.protein_per_100g,fat:candidate.fat_per_100g,carbs:candidate.carbs_per_100g}};
    setItems(replaceIndex === null ? [...items,entry] : items.map((item,i)=>i===replaceIndex ? entry : item));
    setReplaceIndex(null);
    setCandidate(null); setQuery('');
  };
  const update = (index, field, value) => setItems(items.map((item,i)=> i === index ? {...item,[field]:value} : item));
  const totals = items.reduce((t,item)=>{ for(const k of Object.keys(t)) t[k] += Number(item.nutrition_per_100g?.[k] || 0)*Number(item.estimated_mass || 0)/100; return t; }, {calories:0,protein:0,fat:0,carbs:0});
  const save = async e => {
    e.preventDefault();
    if (busy || saved) return;
    if (items.some(item=>item.confidence>0 && !item.mass_confirmed)) {setError('Проверьте состав и приготовление, укажите массу и подтвердите каждый распознанный продукт.');return;}
    if (items.some(item => item.nutrition_missing && !Object.values(item.nutrition_per_100g || {}).some(Number))) {
      setError('Для некоторых продуктов нет КБЖУ. Заполните данные с упаковки или удалите продукт: нули не являются расчётом.'); return;
    }
    setBusy(true); setError('');
    try { await saveMeal({meal_type:mealType,items:items.map(item=>({...item,name:item.name.trim(),estimated_mass:Number(item.estimated_mass)}))}); setSaved(true); }
    catch(err) { setError(typeof err.response?.data?.detail==='string' ? err.response.data.detail : 'Не удалось сохранить. Проверьте данные и повторите.'); }
    finally { setBusy(false); }
  };
  return <div className="results-page"><div className="results-header"><h1>{saved ? 'Обед в дневнике' : 'Проверьте ваш обед'}</h1><p>{saved ? 'Результат сохранён. Он доступен в истории и недельной статистике.' : 'Уточните продукты и массу порций перед сохранением.'}</p></div>
    {!saved && <p className="review-notice">Модель находит видимые продукты и может ошибаться или пропускать ингредиенты. Для начала указано 100 г на продукт — это не измерение веса. Уточните приготовление, общую массу каждого продукта, масло и соусы. Оценка модели не означает точность калорий.</p>}
    <p className="review-help">{items.some(item=>item.nutrition_missing) ? "Частичный итог: для некоторых продуктов пока нет КБЖУ." : items.some(item=>item.confidence>0 && !item.mass_confirmed) ? "Предварительный итог: подтвердите состав и массу порций." : "Итог по указанным порциям."}</p><div className="card review-summary" aria-live="polite"><strong>{Math.round(totals.calories)} <small>ккал</small></strong><span>Белки {Math.round(totals.protein)} г</span><span>Жиры {Math.round(totals.fat)} г</span><span>Углеводы {Math.round(totals.carbs)} г</span></div>
    {scan?.preview && <section className="card detected-photo-card"><h2>Что найдено на фото</h2><div className="detected-photo"><img src={scan.preview} alt="Фотография блюда с областями распознавания"/>{(scan.items || []).flatMap((item,index)=>(item.boxes || []).map((box,j)=><div key={`${index}-${j}`} className="detected-box" style={{left:`${box[0]*100}%`,top:`${box[1]*100}%`,width:`${(box[2]-box[0])*100}%`,height:`${(box[3]-box[1])*100}%`}}><span>{index+1}. {item.name}</span></div>))}</div><p>Рамки показывают предложения модели. Проверьте также продукты вне рамок.</p></section>}
    <form onSubmit={save}><fieldset disabled={busy || saved} className="review-fieldset">
      <label className="review-meal">Приём пищи <select value={mealType} onChange={e=>setMealType(e.target.value)}>{[['breakfast','Завтрак'],['lunch','Обед'],['dinner','Ужин'],['snack','Перекус']].map(([v,l])=><option key={v} value={v}>{l}</option>)}</select></label>
      {items.map((item,index)=><article className="card review-item" key={index}><div className="review-item-top"><span>Продукт {index+1}{item.recognition_method==='cloud' ? ' · предложено облачной моделью, проверьте' : item.confidence>0 ? ` · ${Math.round(item.confidence*100)}% оценка модели` : ' · введён вручную'}</span><button type="button" className="review-remove" onClick={()=>{setReplaceIndex(null);setItems(items.filter((_,i)=>i!==index));}} aria-label={`Удалить продукт ${index+1}`}>Удалить</button></div><div className="review-inputs"><label>Название<input required maxLength={255} value={item.name} onChange={e=>setItems(items.map((entry,i)=>i===index ? {...entry,name:e.target.value,nutrition_missing:true,mass_confirmed:false,source:'Название изменено — проверьте КБЖУ',source_url:null,nutrition_per_100g:{calories:0,protein:0,fat:0,carbs:0}} : entry))}/></label><label>Масса, г<input type="number" required min="1" max="3000" step="1" value={item.estimated_mass} onChange={e=>update(index,'estimated_mass',e.target.value)}/></label>{[['calories','Ккал / 100 г',1000],['protein','Белки / 100 г',100],['fat','Жиры / 100 г',100],['carbs','Углеводы / 100 г',100]].map(([k,label,max])=><label key={k}>{label}<input type="number" required min="0" max={max} step="any" value={item.nutrition_per_100g?.[k] ?? 0} onChange={e=>update(index,'nutrition_per_100g',{...item.nutrition_per_100g,[k]:Number(e.target.value)})}/></label>)}</div><button type="button" className="btn btn-secondary" onClick={()=>{setReplaceIndex(index);setQuery('');setCandidate(null);}}>Заменить продукт из справочника</button>{item.confidence>0 && <label className="confirm-portion"><input type="checkbox" checked={Boolean(item.mass_confirmed)} onChange={e=>update(index,'mass_confirmed',e.target.checked)}/> Состав, приготовление и общая масса этого продукта проверены</label>}<p>{item.source}{item.source_url && <> · <a href={item.source_url} target="_blank" rel="noreferrer">Источник данных</a></>}{item.nutrition_missing ? " · нет данных, заполните КБЖУ" : ""}</p><p className="review-item-total">В порции: {Math.round(Number(item.nutrition_per_100g?.calories || 0)*Number(item.estimated_mass || 0)/100)} ккал</p></article>)}
      <button type="button" className="btn btn-secondary" onClick={()=>setItems([...items,blankItem()])} disabled={items.length>=50}>+ Добавить продукт или соус</button>
      <section className="card student-food-catalog" aria-label="Каталог продуктов">
        <h2>{replaceIndex === null ? "Что было в вашей тарелке?" : `Выберите замену для продукта ${replaceIndex+1}`}</h2>{replaceIndex !== null && <button type="button" className="btn btn-secondary" onClick={()=>setReplaceIndex(null)}>Отменить замену</button>}
        <p>{catalog.filter(f=>f.local).length} продуктов с готовыми КБЖУ без внешних сервисов. Значения справочные, на 100 г съедобной части. Выбирайте правильный способ приготовления.</p>
        <label><input type="checkbox" checked={online} onChange={e=>{setOnline(e.target.checked); setCandidate(null);}}/> Дополнительный онлайн-поиск: {catalog.length} названий, результаты могут отсутствовать</label>
        <label>Фильтр каталога<input value={query} onChange={e=>setQuery(e.target.value)} placeholder="Гречка, курица, помидор…" maxLength={120}/></label>
        <label><input type="checkbox" checked={redOnly} onChange={e=>setRedOnly(e.target.checked)}/> Красные продукты и блюда</label>
        <div className="catalog-options">{catalog.filter(f=>(online || f.local) && (!redOnly || f.red_focus) && f.name.toLocaleLowerCase('ru').replaceAll('ё','е').includes(query.toLocaleLowerCase('ru').replaceAll('ё','е'))).slice(0,24).map(food=><button type="button" className="btn btn-secondary" key={food.id} disabled={searching} onClick={()=>{setQuery(food.name); lookup(food.name);}}>{food.name}</button>)}</div>
        <p>Показаны первые 24 совпадения. Выберите продукт, проверьте карточку ниже и добавьте его в состав. Для сложного блюда укажите ингредиенты отдельно; масло и соусы добавляются отдельно.</p>
      </section>
      <div className="card nutrition-search"><label htmlFor="food-query">Найти данные о продукте</label><div><input id="food-query" maxLength={120} value={query} onChange={e=>setQuery(e.target.value)} placeholder="Например: банан или название с упаковки"/><button type="button" className="btn btn-secondary" disabled={searching || query.trim().length<2} onClick={()=>lookup()}>{searching?'Ищем…':'Найти'}</button></div>{candidate && <article><strong>{candidate.name}</strong><p>{candidate.calories_per_100g} ккал / 100 г · {candidate.source}{candidate.cached?' · из кэша':''}</p><p>Проверьте, что найден именно ваш продукт и способ приготовления.</p>{candidate.source_url && <a href={candidate.source_url} target="_blank" rel="noreferrer">Открыть источник ↗</a>}<button type="button" className="btn btn-secondary" onClick={addCandidate} disabled={items.length>=50}>{replaceIndex === null ? "Добавить найденный продукт" : "Заменить выбранный продукт"}</button></article>}</div>
      <p className="review-help">Для ручного ввода возьмите данные на 100 г с упаковки или технологической карты. Справочные значения могут отличаться от вашего продукта. Общий итог зависит от состава и указанной массы.</p>
      {error && <p role="alert" className="review-error">{error}</p>}
      {!saved && <button className="btn btn-primary" type="submit" disabled={busy || !items.length}>{busy ? 'Сохраняем…' : 'Сохранить в дневник'}</button>}
    </fieldset></form>
    <div className="results-actions">{saved && <button className="btn btn-primary" onClick={()=>navigate('/history')}>Открыть историю</button>}<button className="btn btn-secondary" onClick={()=>navigate('/scan')}>Сканировать ещё</button><button className="btn btn-secondary" onClick={()=>navigate('/dashboard')}>Обзор недели</button></div>
  </div>;
}
