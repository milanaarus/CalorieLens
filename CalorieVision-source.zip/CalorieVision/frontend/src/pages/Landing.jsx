import { lazy, Suspense, useState } from 'react';
import { Link } from 'react-router-dom';
import '../styles/landing.css';

const MealScene = lazy(() => import('../components/MealScene'));

export default function Landing() {
  const [portion, setPortion] = useState(1);
  const signedIn = Boolean(localStorage.getItem('token'));

  return (
    <div className="landing">
      <header className="landing-nav">
        <Link className="cv-wordmark" to="/">CalorieVision</Link>
        <nav aria-label="Главная навигация">
          <a href="#how">Как пользоваться</a>
          <Link className="cv-link" to={signedIn ? '/dashboard' : '/login'}>
            {signedIn ? 'Личный кабинет' : 'Войти / зарегистрироваться'}
          </Link>
        </nav>
        <a className="fa-brand" href="https://www.fa.ru/" target="_blank" rel="noreferrer">
          <img src="/fa-logo.png" alt="Финансовый университет при Правительстве Российской Федерации" />
        </a>
      </header>

      <main className="student-main">
        <section className="cv-hero">
          <div className="cv-intro">
            <p className="student-caption">Учебный проект</p>
            <h1>Подсчёт калорий по фотографии</h1>
            <p className="cv-lead">
              CalorieVision помогает вести дневник питания. Загрузите фотографию блюда,
              проверьте продукты и размер порции, затем сохраните результат.
            </p>
            <Link className="cv-primary" to={signedIn ? '/scan' : '/login'}>Попробовать</Link>
            <p className="cv-note">Для регистрации подходит почта любого домена.</p>
          </div>
          <div className="student-example">
            <Suspense fallback={<p className="student-loading">Загрузка 3D-модели…</p>}>
              <MealScene portion={portion} />
            </Suspense>
            <label className="student-portion" htmlFor="portion">
              Размер порции
              <select id="portion" value={portion} onChange={event => setPortion(Number(event.target.value))}>
                <option value={0.5}>Половина</option>
                <option value={1}>Обычная</option>
                <option value={1.5}>Полторы порции</option>
              </select>
            </label>
            <p className="student-example-note">Пример расчёта. Значения приблизительные.</p>
          </div>
        </section>

        <section className="student-how" id="how">
          <h2>Как пользоваться</h2>
          <ol>
            <li><h3>Загрузите фото</h3><p>Сфотографируйте блюдо или выберите фотографию с устройства.</p></li>
            <li><h3>Проверьте результат</h3><p>Уточните вес и состав. Пропущенные продукты можно добавить вручную.</p></li>
            <li><h3>Сохраните в дневник</h3><p>История приёмов пищи и статистика за неделю доступны в личном кабинете.</p></li>
          </ol>
        </section>

        <section className="student-about">
          <h2>О проекте</h2>
          <p>Это учебный проект студентов Финансового университета. Сервис открыт для всех пользователей.</p>
          <p>Расчёт по фото может ошибаться: масло, соусы и вес порции лучше уточнять самостоятельно.</p>
        </section>
      </main>
      <footer className="cv-footer"><span>CalorieVision</span><span>Учебный проект · Финансовый университет</span></footer>
    </div>
  );
}
