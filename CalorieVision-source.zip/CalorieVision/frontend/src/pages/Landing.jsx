import { lazy, Suspense, useState } from 'react';
import { Link } from 'react-router-dom';
import '../styles/landing.css';

const MealScene = lazy(() => import('../components/MealScene'));

export default function Landing() {
  const [portion, setPortion] = useState(1);
  const signedIn = Boolean(localStorage.getItem('token'));

  return (
    <div className="landing">
      <header className="landing-nav">
        <Link className="cv-wordmark" to="/">CalorieVision</Link>
        <nav aria-label="Главная навигация">
          <a href="#how">Как пользоваться</a>
          <Link className="cv-link" to={signedIn ? '/dashboard' : '/login'}>
            {signedIn ? 'Личный кабинет' : 'Войти / зарегистрироваться'}
          </Link>
        </nav>
        <a className="fa-brand" href="https://www.fa.ru/" target="_blank" rel="noreferrer">
          <img src="/fa-logo.png" alt="Финансовый университет при Правительстве Российской Федерации" />
        </a>
      </header>

      <main className="student-main">
        <section className="cv-hero">
          <div className="cv-intro">
            <p className="student-caption">Учебный проект</p>
            <h1>Подсчёт калорий по фотографии</h1>
            <p className="cv-lead">
              CalorieVision помогает вести дневник питания. Загрузите фотографию блюда,
              проверьте продукты и размер порции, затем сохраните результат.
            </p>
            <Link className="cv-primary" to={signedIn ? '/scan' : '/login'}>Попробовать</Link>
            <p className="cv-note">Для регистрации подходит почта любого домена.</p>
          </div>
          <div className="student-example">
            <Suspense fallback={<p className="student-loading">Загрузка 3D-модели…</p>}>
              <MealScene portion={portion} />
            </Suspense>
            <label className="student-portion" htmlFor="portion">
              Размер порции
              <select id="portion" value={portion} onChange={event => setPortion(Number(event.target.value))}>
                <option value={0.5}>Половина</option>
                <option value={1}>Обычная</option>
                <option value={1.5}>Полторы порции</option>
              </select>
            </label>
            <p className="student-example-note">Пример расчёта. Значения приблизительные.</p>
          </div>
        </section>

        <section className="student-how" id="how">
          <h2>Как пользоваться</h2>
          <ol>
            <li><h3>Загрузите фото</h3><p>Сфотографируйте блюдо или выберите фотографию с устройства.</p></li>
            <li><h3>Проверьте результат</h3><p>Уточните вес и состав. Пропущенные продукты можно добавить вручную.</p></li>
            <li><h3>Сохраните в дневник</h3><p>История приёмов пищи и статистика за неделю доступны в личном кабинете.</p></li>
          </ol>
        </section>

        <section className="student-about" id="about" aria-labelledby="about-title">
          <h2 id="about-title">О проекте</h2>
          <p>
            CalorieVision — учебный проект студентов Финансового университета, который помогает
            вести дневник питания. По фотографии блюда можно получить предварительную оценку
            калорий, белков, жиров и углеводов, уточнить состав и порцию, а затем сохранить приём пищи.
          </p>
          <h3>Для кого</h3>
          <p>
            В первую очередь — для студентов и преподавателей, которым хочется следить за питанием
            в привычном ритме учёбы и работы. Пообедали в столовой, взяли еду с собой или перекусили
            между парами — запись можно добавить с телефона. Сервис открыт для всех: для регистрации
            не нужна университетская почта.
          </p>
          <h3>Чем он полезен</h3>
          <p>
            Фотография помогает начать запись, а возможность исправить продукты и их вес — уточнить
            расчёт. Дневник хранит приёмы пищи в одном месте, а статистика за неделю помогает увидеть,
            как меняется калорийность питания. Если нужный продукт не распознан, его можно добавить вручную.
          </p>
          <h3>Почему мы выбрали этот проект</h3>
          <p>
            Питание — повседневная задача, знакомая каждому студенту. Нам интересно применить
            компьютерное зрение к этой задаче и объединить распознавание еды, расчёт пищевой ценности
            и дневник в одном приложении. Так учебная работа с технологиями превращается в инструмент,
            которым можно пользоваться каждый день.
          </p>
          <p className="student-about-note">
            Расчёт по фото приблизительный: камера не всегда определяет вес порции, масло и соусы.
            Перед сохранением стоит проверить результат.
          </p>
        </section>
      </main>
      <footer className="cv-footer"><span>CalorieVision</span><span>Учебный проект · Финансовый университет</span></footer>
    </div>
  );
}
