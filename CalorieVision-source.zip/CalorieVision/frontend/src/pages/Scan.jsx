import Icon from '../components/Icon';
import { useState, useRef, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { scanFood } from '../api/client';
import '../styles/scan.css';

const Scan = () => {
  const navigate = useNavigate();
  const videoRef = useRef(null);
  const fileInputRef = useRef(null);

  const [stream, setStream] = useState(null);
  const streamRef = useRef(null);
  const [cameraActive, setCameraActive] = useState(false);
  const [preview, setPreview] = useState(null);
  const [selectedFile, setSelectedFile] = useState(null);
  const [mealType, setMealType] = useState('lunch');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [noFood, setNoFood] = useState(false);

  // Запуск камеры
  const startCamera = async () => {
    try {
      const mediaStream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: 'environment' },
      });
      streamRef.current = mediaStream;
      setStream(mediaStream);
      if (videoRef.current) {
        videoRef.current.srcObject = mediaStream;
      }
      setCameraActive(true);
    } catch (err) {
      setError('Не удалось получить доступ к камере: ' + err.message);
    }
  };

  // Остановка камеры
  const stopCamera = () => {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach((track) => track.stop());
      streamRef.current = null;
      setStream(null);
    }
    setCameraActive(false);
  };

  // Сделать снимок
  const capturePhoto = () => {
    if (!videoRef.current || !videoRef.current.videoWidth) return;

    const canvas = document.createElement('canvas');
    canvas.width = videoRef.current.videoWidth;
    canvas.height = videoRef.current.videoHeight;
    const ctx = canvas.getContext('2d');
    ctx.drawImage(videoRef.current, 0, 0);

    canvas.toBlob((blob) => {
      if (!blob) return;
      const file = new File([blob], 'capture.jpg', { type: 'image/jpeg' });
      setNoFood(false);
      setSelectedFile(file);
      setPreview(URL.createObjectURL(blob));
      stopCamera();
    }, 'image/jpeg');
  };

  // Загрузка файла
  const handleFileChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      if (!["image/jpeg", "image/png", "image/webp"].includes(file.type) || file.size > 10 * 1024 * 1024) {
        setError("Загрузите JPEG, PNG или WebP размером до 10 МБ"); return;
      }
      setError(null);
      setNoFood(false);
      setSelectedFile(file);
      setPreview(URL.createObjectURL(file));
    }
  };

  // Сброс
  const reset = () => {
    setNoFood(false);
    if (fileInputRef.current) fileInputRef.current.value = '';
    setPreview(null);
    setSelectedFile(null);
    setError(null);
    stopCamera();
  };

  // Превью переносится как компактный снимок: object URL очищается при уходе.
  const createPreview = async () => {
    if (!preview) return null;
    const image = new Image(); image.src = preview; await image.decode();
    const canvas = document.createElement('canvas');
    const scale = Math.min(1, 900 / Math.max(image.naturalWidth, image.naturalHeight));
    canvas.width = Math.round(image.naturalWidth * scale);
    canvas.height = Math.round(image.naturalHeight * scale);
    canvas.getContext('2d').drawImage(image, 0, 0, canvas.width, canvas.height);
    return canvas.toDataURL('image/jpeg', 0.8);
  };

  const enterManually = async () => {
    setLoading(true); setError(null);
    try {
      const photo = await createPreview();
      navigate('/results', {state:{scan:{items:[],meal_type:mealType,preview:photo,manual:true}}});
    } catch {
      setError('Не удалось подготовить фото. Повторите попытку или выберите другое изображение.');
    } finally { setLoading(false); }
  };

  const handleScan = async () => {
    if (!selectedFile || loading) return;
    setLoading(true); setError(null); setNoFood(false);
    try {
      const result = await scanFood(selectedFile, mealType);
      if (result.success && result.items?.length) {
        const photo = await createPreview();
        navigate('/results', {state:{scan:{...result,meal_type:mealType,preview:photo}}});
      } else {
        setNoFood(true);
      }
    } catch (err) {
      const detail = err.response?.data?.detail;
      setError(typeof detail === 'string' ? detail : 'Не удалось выполнить распознавание. Проверьте соединение и попробуйте ещё раз. Можно добавить продукты вручную.');
    } finally { setLoading(false); }
  };

  useEffect(() => {
    if (cameraActive && videoRef.current) videoRef.current.srcObject = stream;
  }, [cameraActive, stream]);
  useEffect(() => () => { if (preview) URL.revokeObjectURL(preview); }, [preview]);
  useEffect(() => () => { streamRef.current?.getTracks().forEach(t => t.stop()); }, []);

  return (
    <div className="scan-page">
      <div className="scan-header">
        <h1>Сфотографируйте блюдо</h1>
        <p>Сфотографируйте блюдо или загрузите фото</p>
      </div>

      <div className="scan-container">
        {/* Левая часть — камера / превью */}
        <div className="scan-viewer">
          {preview ? (
            <img src={preview} alt="Preview" className="preview-image" />
          ) : cameraActive ? (
            <video
              ref={videoRef}
              autoPlay
              playsInline
              className="camera-video"
            />
          ) : (
            <div className="scan-placeholder">
              <div className="placeholder-icon"><Icon name="camera" /></div>
              <p>Камера выключена</p>
              <p className="placeholder-hint">
                Нажмите "Открыть камеру" или загрузите фото
              </p>
            </div>
          )}

          {cameraActive && !preview && (
            <button className="capture-btn" onClick={capturePhoto}>
              <div className="capture-inner"></div>
            </button>
          )}
        </div>

        {/* Правая часть — управление */}
        <div className="scan-controls">
          <div className="control-group">
            <label className="control-label">Тип приёма пищи</label>
            <div className="meal-type-buttons">
              {[
                { value: 'breakfast', label: 'Завтрак' },
                { value: 'lunch', label: 'Обед' },
                { value: 'dinner', label: 'Ужин' },
                { value: 'snack', label: 'Перекус' },
              ].map((type) => (
                <button
                  key={type.value}
                  className={`meal-type-btn ${
                    mealType === type.value ? 'active' : ''
                  }`}
                  disabled={loading}
                  onClick={() => setMealType(type.value)}
                >
                  {type.label}
                </button>
              ))}
            </div>
          </div>

          {error && <div role="alert" className="error-message">{error}</div>}
          {noFood && <section className="scan-empty" role="status">
            <h2>Продукты на фото не найдены</h2>
            <p>Модель могла пропустить еду. Снимите блюдо поближе при хорошем освещении или добавьте состав вручную.</p>
            <p>Фото и выбранный приём пищи сохранятся при ручном вводе. Запись попадёт в дневник только после вашего подтверждения.</p>
            <div className="action-buttons">
              <button className="btn btn-secondary" disabled={loading} onClick={() => fileInputRef.current.click()}>Выбрать другое фото</button>
              <button className="btn btn-primary" disabled={loading} onClick={enterManually}>Добавить продукты вручную</button>
            </div>
          </section>}
          <div className="control-group">
            <h2>Соберите состав тарелки</h2>
            <p>Используется исходная YOLOv8n: банан, яблоко, апельсин, брокколи, морковь, сэндвич, пицца, хот-дог, пончик и торт. Модель может ошибаться. Проверьте продукты и укажите массу; пропущенные ингредиенты можно добавить вручную.</p>
          </div>
          <button className="btn btn-secondary" disabled={loading} onClick={enterManually}>Ввести состав вручную</button>

          <input ref={fileInputRef} type="file" accept="image/jpeg,image/png,image/webp"
            onClick={e => { e.currentTarget.value = ''; }} onChange={handleFileChange} disabled={loading} style={{display:'none'}} />
          <div className="action-buttons">
            {!preview && !cameraActive && (
              <>
                <button className="btn btn-primary" onClick={startCamera}>
                  <Icon name="camera" /> Открыть камеру
                </button>
                <button
                  className="btn btn-secondary"
                  onClick={() => fileInputRef.current.click()}
                >
                  <Icon name="upload" /> Загрузить фото
                </button>

              </>
            )}

            {preview && (
              <>
                <button
                  className="btn btn-primary"
                  onClick={handleScan}
                  disabled={loading}
                >
                  {loading ? <>Анализируем…</> : <><Icon name="search" /> Распознать</>}
                </button>
                <button className="btn btn-secondary" disabled={loading} onClick={reset}>
                  <Icon name="reset" /> Сбросить
                </button>
              </>
            )}

            {cameraActive && !preview && (
              <button className="btn btn-secondary" onClick={stopCamera}>
                <Icon name="close" /> Закрыть камеру
              </button>
            )}
          </div>

          {loading && (
            <div className="loading-indicator">
              <div className="spinner"></div>
              <p>ИИ анализирует ваше блюдо...</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default Scan;
