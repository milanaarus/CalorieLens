import Icon from '../components/Icon';
import { useState, useRef, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { scanFood, getFoodCatalog } from '../api/client';
import '../styles/scan.css';

const Scan = () => {
  const navigate = useNavigate();
  const videoRef = useRef(null);
  const fileInputRef = useRef(null);

  const [stream, setStream] = useState(null);
  const streamRef = useRef(null);
  const [cameraActive, setCameraActive] = useState(false);
  const [preview, setPreview] = useState(null);
  const [selectedFile, setSelectedFile] = useState(null);
  const [mealType, setMealType] = useState('lunch');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [cloudAvailable, setCloudAvailable] = useState(false);
  const [cloudConsent, setCloudConsent] = useState(false);
  useEffect(() => { getFoodCatalog().then(data => setCloudAvailable(data.cloud_available)).catch(() => {}); }, []);

  // Запуск камеры
  const startCamera = async () => {
    try {
      const mediaStream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: 'environment' },
      });
      streamRef.current = mediaStream;
      setStream(mediaStream);
      if (videoRef.current) {
        videoRef.current.srcObject = mediaStream;
      }
      setCameraActive(true);
    } catch (err) {
      setError('Не удалось получить доступ к камере: ' + err.message);
    }
  };

  // Остановка камеры
  const stopCamera = () => {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach((track) => track.stop());
      streamRef.current = null;
      setStream(null);
    }
    setCameraActive(false);
  };

  // Сделать снимок
  const capturePhoto = () => {
    if (!videoRef.current || !videoRef.current.videoWidth) return;

    const canvas = document.createElement('canvas');
    canvas.width = videoRef.current.videoWidth;
    canvas.height = videoRef.current.videoHeight;
    const ctx = canvas.getContext('2d');
    ctx.drawImage(videoRef.current, 0, 0);

    canvas.toBlob((blob) => {
      if (!blob) return;
      const file = new File([blob], 'capture.jpg', { type: 'image/jpeg' });
      setSelectedFile(file);
      setPreview(URL.createObjectURL(blob));
      stopCamera();
    }, 'image/jpeg');
  };

  // Загрузка файла
  const handleFileChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      if (!["image/jpeg", "image/png", "image/webp"].includes(file.type) || file.size > 10 * 1024 * 1024) {
        setError("Загрузите JPEG, PNG или WebP размером до 10 МБ"); return;
      }
      setError(null);
      setSelectedFile(file);
      setPreview(URL.createObjectURL(file));
    }
  };

  // Сброс
  const reset = () => {
    setPreview(null);
    setSelectedFile(null);
    setError(null);
    stopCamera();
  };

  // Отправка на сервер
  const handleScan = async () => {
    if (!selectedFile) return;

    setLoading(true);
    setError(null);

    try {
      const result = await scanFood(selectedFile, mealType, cloudAvailable && cloudConsent);

      if (result.success) {
        // Переходим на страницу результатов с данными
        navigate('/results', { state: { scan: result } });
      } else {
        setError(result.message || 'Не удалось распознать продукты');
      }
    } catch (err) {
      setError('Ошибка сервера: ' + (err.response?.data?.detail || err.message));
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (cameraActive && videoRef.current) videoRef.current.srcObject = stream;
  }, [cameraActive, stream]);
  useEffect(() => () => { if (preview) URL.revokeObjectURL(preview); }, [preview]);
  useEffect(() => () => { streamRef.current?.getTracks().forEach(t => t.stop()); }, []);

  return (
    <div className="scan-page">
      <div className="scan-header">
        <h1>Сфотографируйте блюдо</h1>
        <p>Сфотографируйте блюдо или загрузите фото</p>
      </div>

      <div className="scan-container">
        {/* Левая часть — камера / превью */}
        <div className="scan-viewer">
          {preview ? (
            <img src={preview} alt="Preview" className="preview-image" />
          ) : cameraActive ? (
            <video
              ref={videoRef}
              autoPlay
              playsInline
              className="camera-video"
            />
          ) : (
            <div className="scan-placeholder">
              <div className="placeholder-icon"><Icon name="camera" /></div>
              <p>Камера выключена</p>
              <p className="placeholder-hint">
                Нажмите "Открыть камеру" или загрузите фото
              </p>
            </div>
          )}

          {cameraActive && !preview && (
            <button className="capture-btn" onClick={capturePhoto}>
              <div className="capture-inner"></div>
            </button>
          )}
        </div>

        {/* Правая часть — управление */}
        <div className="scan-controls">
          <div className="control-group">
            <label className="control-label">Тип приёма пищи</label>
            <div className="meal-type-buttons">
              {[
                { value: 'breakfast', label: 'Завтрак' },
                { value: 'lunch', label: 'Обед' },
                { value: 'dinner', label: 'Ужин' },
                { value: 'snack', label: 'Перекус' },
              ].map((type) => (
                <button
                  key={type.value}
                  className={`meal-type-btn ${
                    mealType === type.value ? 'active' : ''
                  }`}
                  onClick={() => setMealType(type.value)}
                >
                  {type.label}
                </button>
              ))}
            </div>
          </div>

          {error && <div role="alert" className="error-message">{error}</div>}
          <div className="control-group">
            <h2>Вся тарелка и красные продукты</h2>
            <p>Каталог студенческого питания: овощи, гарниры, супы, основные блюда и перекусы. Массу каждого продукта нужно уточнить.</p>
            {cloudAvailable ? <label><input type="checkbox" checked={cloudConsent} onChange={e => setCloudConsent(e.target.checked)} /> Разрешаю отправить фото в Hugging Face и выбранному провайдеру модели для анализа всей тарелки. Не загружайте фото с лицами и личными данными.</label> : <p>Облачное распознавание всей тарелки пока не подключено. Сейчас работает базовая модель на 10 категорий; остальные продукты можно выбрать из каталога.</p>}
          </div>
          <button className="btn btn-secondary" onClick={() => navigate("/results")}>Ввести состав вручную</button>

          <div className="action-buttons">
            {!preview && !cameraActive && (
              <>
                <button className="btn btn-primary" onClick={startCamera}>
                  <Icon name="camera" /> Открыть камеру
                </button>
                <button
                  className="btn btn-secondary"
                  onClick={() => fileInputRef.current.click()}
                >
                  <Icon name="upload" /> Загрузить фото
                </button>
                <input
                  ref={fileInputRef}
                  type="file"
                  accept="image/jpeg,image/png,image/webp"
                  onChange={handleFileChange}
                  style={{ display: 'none' }}
                />
              </>
            )}

            {preview && (
              <>
                <button
                  className="btn btn-primary"
                  onClick={handleScan}
                  disabled={loading}
                >
                  {loading ? <>Анализируем…</> : <><Icon name="search" /> Распознать</>}
                </button>
                <button className="btn btn-secondary" onClick={reset}>
                  <Icon name="reset" /> Сбросить
                </button>
              </>
            )}

            {cameraActive && !preview && (
              <button className="btn btn-secondary" onClick={stopCamera}>
                <Icon name="close" /> Закрыть камеру
              </button>
            )}
          </div>

          {loading && (
            <div className="loading-indicator">
              <div className="spinner"></div>
              <p>ИИ анализирует ваше блюдо...</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default Scan;
