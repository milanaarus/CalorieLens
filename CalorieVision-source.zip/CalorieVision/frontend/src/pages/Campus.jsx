import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import '../styles/review.css';

const examples = [
  {name:'Курица',estimated_mass:150,price:0,confidence:0,nutrition_per_100g:{calories:165,protein:31,fat:3.6,carbs:0}},
  {name:'Рис отварной',estimated_mass:150,price:0,confidence:0,nutrition_per_100g:{calories:130,protein:2.7,fat:0.3,carbs:28}},
  {name:'Овощи',estimated_mass:100,price:0,confidence:0,nutrition_per_100g:{calories:35,protein:1.5,fat:0.3,carbs:6}},
];
export default function Campus() {
  const navigate = useNavigate();
  const [budget,setBudget]=useState(350);
  const [items,setItems]=useState(examples.map(i=>({...i})));
  const [priceEntered,setPriceEntered]=useState(false);
  const update=(index,key,value)=>{ if(key==='price')setPriceEntered(true); setItems(items.map((x,i)=>i===index?{...x,[key]:Number(value)}:x)); };
  const price=items.reduce((n,i)=>n+i.price,0);
  const calories=items.reduce((n,i)=>n+i.estimated_mass*i.nutrition_per_100g.calories/100,0);
  return <div className="results-page"><div className="results-header"><h1>Соберите обед между парами</h1><p>Порция, состав и бюджет — в одном месте.</p></div><p className="campus-intro">Планируйте обед заранее: задайте порции и внесите цены, которые видите в столовой. Затем проверьте состав и сохраните обед в личный дневник.</p><div className="campus-controls"><label>Бюджет обеда, ₽<input type="number" min="0" max="100000" value={budget} onChange={e=>setBudget(Number(e.target.value))}/></label><strong>{Math.round(calories)} ккал в примере</strong></div><div className="campus-options">{items.map((item,i)=><article className="card campus-option" key={item.name}><h2>{item.name}</h2><p>{item.nutrition_per_100g.calories} ккал на 100 г</p><label>Порция, г<input type="number" min="1" max="3000" value={item.estimated_mass} onChange={e=>update(i,'estimated_mass',Math.max(1,Math.min(3000,Number(e.target.value))))}/></label><label>Цена порции, ₽<input type="number" min="0" max="100000" value={item.price} onChange={e=>update(i,'price',Math.max(0,Number(e.target.value)))}/></label><p>{Math.round(item.estimated_mass*item.nutrition_per_100g.calories/100)} ккал</p></article>)}</div><div className={`campus-budget ${price>budget?'over':''}`} aria-live="polite">{priceEntered ? `Стоимость: ${price.toLocaleString('ru-RU')} ₽. ${price<=budget ? `Осталось ${budget-price} ₽ в бюджете.` : `Превышение бюджета: ${price-budget} ₽.`}` : 'Укажите фактические цены порций, чтобы сравнить обед с бюджетом.'}</div><p className="campus-disclaimer">Это пример конструктора, а не действующее меню столовой. Значения питания ориентировочные: замените их данными конкретного блюда на следующем шаге. Цены служат для планирования и пока не сохраняются в дневнике.</p><button className="btn btn-primary" onClick={()=>navigate('/results',{state:{scan:{meal_type:'lunch',items:items.map(({price,...item})=>item)}}})}>Проверить состав и сохранить</button></div>;
}
