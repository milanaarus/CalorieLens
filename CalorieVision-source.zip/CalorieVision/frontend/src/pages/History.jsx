import Icon from '../components/Icon';
import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { getScans, getWeeklyStats, deleteScan, getProfile } from '../api/client';
import '../styles/history.css';

const History = () => {
  const navigate = useNavigate();
  const [scans, setScans] = useState([]);
  const [weeklyStats, setWeeklyStats] = useState([]);
  const [dailyGoal, setDailyGoal] = useState(2200);
  const [filter, setFilter] = useState('all');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      const [scansData, statsData, profile] = await Promise.all([
        getScans(50),
        getWeeklyStats(),
        getProfile(),
      ]);
      setScans(scansData.scans || []);
      setDailyGoal(profile.daily_calorie_goal || 2200);
      setWeeklyStats(statsData.days || []);
    } catch (error) {
      console.error('Ошибка загрузки:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleDelete = async (id) => {
    if (!confirm('Удалить этот скан?')) return;
    try {
      await deleteScan(id);
      setScans(scans.filter((s) => s.id !== id));
    } catch (error) {
      console.error('Ошибка удаления:', error);
    }
  };

  const filteredScans =
    filter === 'all' ? scans : scans.filter((s) => s.meal_type === filter);

  const maxCalories = Math.max(...weeklyStats.map((d) => d.total_calories), 1);

  const mealIcons = {
    breakfast: <Icon name="sun" />,
    lunch: <Icon name="plate" />,
    dinner: <Icon name="moon" />,
    snack: <Icon name="leaf" />,
  };

  const mealLabels = {
    breakfast: 'Завтрак',
    lunch: 'Обед',
    dinner: 'Ужин',
    snack: 'Перекус',
  };



  return (
    <div className="history-page">
      <div className="history-header">
        <h1>История питания</h1>
        <p>Ваша история питания и статистика</p>
      </div>

      {/* Календарь недели */}
      <div className="card weekly-card">
        <div className="card-title">Ваша неделя</div>
        <div className="weekly-grid">
          {weeklyStats.map((day, index) => {
            const isOverGoal = day.total_calories > dailyGoal;
            const hasData = day.total_calories > 0;

            return (
              <div key={index} className="day-column">
                <div className="day-name">
                  {new Date(day.date).toLocaleDateString('ru-RU', {
                    weekday: 'short',
                  })}
                </div>
                <div
                  className={`day-circle ${
                    hasData ? (isOverGoal ? 'over' : 'under') : 'empty'
                  }`}
                >
                  {new Date(day.date).getDate()}
                </div>
                <div className="day-calories">
                  {hasData ? `${Math.round(day.total_calories)}` : '—'}
                </div>
                <div className="day-label">ккал</div>
              </div>
            );
          })}
        </div>
      </div>

      {/* График */}
      <div className="card chart-card">
        <div className="card-title">Weekly Calorie Trend</div>
        <div className="chart">
          {weeklyStats.map((day, index) => {
            const height = (day.total_calories / maxCalories) * 100;
            return (
              <div key={index} className="chart-bar-container">
                <div className="chart-value">
                  {day.total_calories > 0 ? Math.round(day.total_calories) : ''}
                </div>
                <div
                  className={`chart-bar ${
                    day.total_calories > dailyGoal ? 'over' : ''
                  }`}
                  style={{ height: `${height}%` }}
                ></div>
                <div className="chart-label">
                  {new Date(day.date).toLocaleDateString('ru-RU', {
                    weekday: 'short',
                  })}
                </div>
              </div>
            );
          })}
        </div>
        <div className="chart-legend">
          <span>
            <span className="legend-dot green"></span> Под нормой
          </span>
          <span>
            <span className="legend-dot red"></span> Сверх нормы
          </span>
        </div>
      </div>

      {/* Фильтры */}
      <div className="filter-buttons">
        {[
          { value: 'all', label: 'Все' },
          { value: 'breakfast', label: 'Завтрак' },
          { value: 'lunch', label: 'Обед' },
          { value: 'dinner', label: 'Ужин' },
          { value: 'snack', label: 'Перекус' },
        ].map((f) => (
          <button
            key={f.value}
            className={`filter-btn ${filter === f.value ? 'active' : ''}`}
            onClick={() => setFilter(f.value)}
          >
            {f.label}
          </button>
        ))}
      </div>

      {/* Список сканов */}
      <div className="card">
        <div className="card-title">
          Meal History ({filteredScans.length})
        </div>
        {loading ? (
          <p>Загрузка...</p>
        ) : filteredScans.length === 0 ? (
          <p style={{ color: '#666', padding: '20px 0' }}>
            Пока нет записей. Сканируйте еду, чтобы начать!
          </p>
        ) : (
          <div className="scans-list">
            {filteredScans.map((scan) => (
              <div key={scan.id} className="scan-item">
                <div className="scan-icon">
                  {mealIcons[scan.meal_type] || <Icon name="plate" />}
                </div>
                <div className="scan-info">
                  <div className="scan-name">
                    {mealLabels[scan.meal_type] || scan.meal_type}
                  </div>
                  <div className="scan-date">
                    {new Date(scan.created_at).toLocaleDateString('ru-RU', {
                      day: 'numeric',
                      month: 'short',
                      hour: '2-digit',
                      minute: '2-digit',
                    })}
                  </div>
                  <div className="scan-macros">
                    Б: {Math.round(scan.total_protein)}г · Ж:{' '}
                    {Math.round(scan.total_fat)}г · У:{' '}
                    {Math.round(scan.total_carbs)}г
                  </div>
                </div>
                <div className="scan-calories">
                  {Math.round(scan.total_calories)} ккал
                </div>
                <button
                  className="delete-btn"
                  onClick={() => handleDelete(scan.id)}
                  title="Удалить"
                >
                  <Icon name="trash" />
                </button>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export default History;
