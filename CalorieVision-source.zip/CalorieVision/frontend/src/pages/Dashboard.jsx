import Icon from '../components/Icon';
import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { getScans, getSummaryStats, getProfile } from '../api/client';
import '../styles/dashboard.css';

const Dashboard = () => {
  const navigate = useNavigate();
  const [scans, setScans] = useState([]);
  const [loading, setLoading] = useState(true);

  const [dailyGoal, setDailyGoal] = useState(2200);
  const [summary, setSummary] = useState({calories:0,protein:0,fat:0,carbs:0});

  useEffect(() => {
    loadScans();
  }, []);

  const loadScans = async () => {
    try {
      const [data, stats, profile] = await Promise.all([getScans(5), getSummaryStats(), getProfile()]);
      setSummary(stats.today);
      setDailyGoal(profile.daily_calorie_goal || 2200);
      setScans(data.scans || []);
    } catch (error) {
      console.error('Ошибка загрузки:', error);
    } finally {
      setLoading(false);
    }
  };

  const todayCalories = summary.calories;
  const todayProtein = summary.protein;
  const todayFat = summary.fat;
  const todayCarbs = summary.carbs;

  const progress = Math.min((todayCalories / dailyGoal) * 100, 100);

  const mealIcons = {
    breakfast: <Icon name="sun" />,
    lunch: <Icon name="plate" />,
    dinner: <Icon name="moon" />,
    snack: <Icon name="leaf" />,
  };

  return (
    <div className="dashboard">
      <div className="dashboard-header">
        <h1>Сегодня</h1>
        <p>Отслеживайте свой прогресс за сегодня</p>
      </div>

      <div className="dashboard-grid">
        <div className="card">
          <div className="card-title">Питание за сегодня</div>
          <div className="calorie-ring">
            <div
              className="ring"
              style={{
                background: `conic-gradient(#0198af 0% ${progress}%, #e5e7eb ${progress}% 100%)`,
              }}
            >
              <div className="ring-inner">
                <div className="ring-value">{Math.round(todayCalories)}</div>
                <div className="ring-label">из {dailyGoal} ккал</div>
              </div>
            </div>

            <div className="macros">
              <div className="macro carb">
                <div className="macro-value">{Math.round(todayCarbs)}г</div>
                <div className="macro-label">Углеводы</div>
              </div>
              <div className="macro protein">
                <div className="macro-value">{Math.round(todayProtein)}г</div>
                <div className="macro-label">Белки</div>
              </div>
              <div className="macro fat">
                <div className="macro-value">{Math.round(todayFat)}г</div>
                <div className="macro-label">Жиры</div>
              </div>
            </div>
          </div>
        </div>

        <div className="card">
          <div className="card-title">Последние приёмы пищи</div>
          <div className="recent-meals">
            {loading ? (
              <p>Загрузка...</p>
            ) : scans.length === 0 ? (
              <p style={{ color: '#666' }}>
                Пока нет сканирований. Нажмите "Сканировать блюдо" чтобы начать!
              </p>
            ) : (
              scans.slice(0, 4).map((scan) => (
                <div key={scan.id} className="meal-item">
                  <div className="meal-icon">
                    {mealIcons[scan.meal_type] || <Icon name="plate" />}
                  </div>
                  <div className="meal-info">
                    <div className="meal-name">
                      {scan.meal_type.charAt(0).toUpperCase() +
                        scan.meal_type.slice(1)}
                    </div>
                    <div className="meal-time">
                      {new Date(scan.created_at).toLocaleTimeString('ru-RU', {
                        hour: '2-digit',
                        minute: '2-digit',
                      })}
                    </div>
                  </div>
                  <div className="meal-calories">
                    {Math.round(scan.total_calories)} ккал
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      </div>

      <button className="scan-btn" onClick={() => navigate('/scan')}>
        <Icon name="camera" /> Сканировать блюдо
      </button>
    </div>
  );
};

export default Dashboard;
