import Icon from '../components/Icon';
import { useEffect, useState } from 'react';
import { getProfile, updateProfile, getProfileStats } from '../api/client';
import '../styles/profile.css';

const Profile = () => {
  const [profile, setProfile] = useState(null);
  const [stats, setStats] = useState(null);
  const [editing, setEditing] = useState(false);
  const [formData, setFormData] = useState({});
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      const [profileData, statsData] = await Promise.all([
        getProfile(),
        getProfileStats(),
      ]);
      setProfile(profileData);
      setFormData(profileData);
      setStats(statsData);
    } catch (error) {
      console.error('Ошибка загрузки:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleChange = (field, value) => {
    setFormData({ ...formData, [field]: value });
  };

  const handleSave = async () => {
    setSaving(true);
    try {
      const result = await updateProfile(formData);
      if (result.success) {
        setProfile(result.profile);
        setEditing(false);
        setSaved(true);
        setTimeout(() => setSaved(false), 3000);
      }
    } catch (error) {
      console.error('Ошибка сохранения:', error);
    } finally {
      setSaving(false);
    }
  };

  const handleCancel = () => {
    setFormData(profile);
    setEditing(false);
  };

  if (loading) {
    return <div className="profile-page"><p>Загрузка...</p></div>;
  }

  // Расчет ИМТ
  const bmi = profile.weight / Math.pow(profile.height / 100, 2);
  const bmiCategory =
    bmi < 18.5 ? 'Недостаточный вес'
    : bmi < 25 ? 'Норма'
    : bmi < 30 ? 'Избыточный вес'
    : 'Ожирение';

  // Рекомендуемые калории (формула Миффлина-Сан Жеора)
  const bmr =
    10 * profile.weight +
    6.25 * profile.height -
    5 * profile.age + 5; // для мужчин, для женщин -161

  const activityMultipliers = {
    sedentary: 1.2,
    light: 1.375,
    moderate: 1.55,
    active: 1.725,
    very_active: 1.9,
  };

  const recommendedCalories = Math.round(
    bmr * (activityMultipliers[profile.activity_level] || 1.55)
  );

  return (
    <div className="profile-page">
      <div className="profile-header">
        <h1>Профиль и настройки</h1>
        <p>Управляйте своими данными и целями</p>
      </div>

      {saved && (
        <div className="success-banner">
          <Icon name="check" /> Профиль успешно сохранён!
        </div>
      )}

      <div className="profile-grid">
        {/* Карточка пользователя */}
        <div className="card user-card">
          <div className="user-avatar">
            {profile.name?.charAt(0).toUpperCase() || 'U'}
          </div>
          <div className="user-name">{profile.name || 'Пользователь'}</div>
          <div className="user-email">{profile.email}</div>

          {!editing ? (
            <button
              className="btn btn-primary edit-btn"
              onClick={() => setEditing(true)}
            >
              <Icon name="edit" /> Редактировать
            </button>
          ) : (
            <div className="edit-actions">
              <button
                className="btn btn-primary"
                onClick={handleSave}
                disabled={saving}
              >
                {saving ? <>Сохранение…</> : <><Icon name="save" /> Сохранить</>}
              </button>
              <button className="btn btn-secondary" onClick={handleCancel}>
                <Icon name="close" /> Отмена
              </button>
            </div>
          )}
        </div>

        {/* Параметры тела */}
        <div className="card">
          <div className="card-title">Параметры профиля</div>
          <div className="form-group">
            <label>Имя</label>
            {editing ? (
              <input
                type="text"
                value={formData.name || ''}
                onChange={(e) => handleChange('name', e.target.value)}
              />
            ) : (
              <div className="value">{profile.name}</div>
            )}
          </div>

          <div className="form-row">
            <div className="form-group">
              <label>Вес (кг)</label>
              {editing ? (
                <input
                  type="number"
                  value={formData.weight || 0}
                  onChange={(e) =>
                    handleChange('weight', parseFloat(e.target.value))
                  }
                />
              ) : (
                <div className="value">{profile.weight} кг</div>
              )}
            </div>
            <div className="form-group">
              <label>Рост (см)</label>
              {editing ? (
                <input
                  type="number"
                  value={formData.height || 0}
                  onChange={(e) =>
                    handleChange('height', parseFloat(e.target.value))
                  }
                />
              ) : (
                <div className="value">{profile.height} см</div>
              )}
            </div>
          </div>

          <div className="form-group">
            <label>Возраст</label>
            {editing ? (
              <input
                type="number"
                value={formData.age || 0}
                onChange={(e) =>
                  handleChange('age', parseInt(e.target.value))
                }
              />
            ) : (
              <div className="value">{profile.age} лет</div>
            )}
          </div>

          <div className="bmi-card">
            <div className="bmi-label">ИМТ</div>
            <div className="bmi-value">{bmi.toFixed(1)}</div>
            <div className="bmi-category">{bmiCategory}</div>
          </div>
        </div>

        {/* Цели */}
        <div className="card">
          <div className="card-title">Nutrition Targets</div>

          <div className="form-group">
            <label>Дневная цель (ккал)</label>
            {editing ? (
              <input
                type="number"
                value={formData.daily_calorie_goal || 0}
                onChange={(e) =>
                  handleChange('daily_calorie_goal', parseFloat(e.target.value))
                }
              />
            ) : (
              <div className="value big">{profile.daily_calorie_goal} ккал</div>
            )}
            <div className="hint">
              Рекомендуем: {recommendedCalories} ккал
            </div>
          </div>

          <div className="form-group">
            <label>Уровень активности</label>
            {editing ? (
              <select
                value={formData.activity_level || 'moderate'}
                onChange={(e) => handleChange('activity_level', e.target.value)}
              >
                <option value="sedentary">Сидячий (мало упражнений)</option>
                <option value="light">Лёгкий (1-2 раза/нед)</option>
                <option value="moderate">Средний (3-4 раза/нед)</option>
                <option value="active">Активный (5-6 раз/нед)</option>
                <option value="very_active">Очень активный (каждый день)</option>
              </select>
            ) : (
              <div className="value">
                {{
                  sedentary: 'Сидячий',
                  light: 'Лёгкий',
                  moderate: 'Средний',
                  active: 'Активный',
                  very_active: 'Очень активный',
                }[profile.activity_level] || profile.activity_level}
              </div>
            )}
          </div>
        </div>

        {/* Статистика */}
        <div className="card">
          <div className="card-title">Your Statistics</div>
          <div className="stats-grid">
            <div className="stat-item">
              <div className="stat-value">{stats.total_scans}</div>
              <div className="stat-label">Всего сканов</div>
            </div>
            <div className="stat-item">
              <div className="stat-value">
                {Math.round(stats.total_calories)}
              </div>
              <div className="stat-label">Всего ккал</div>
            </div>
            <div className="stat-item">
              <div className="stat-value">
                {Math.round(stats.avg_calories_per_day)}
              </div>
              <div className="stat-label">Сред. ккал/день</div>
            </div>
            <div className="stat-item">
              <div className="stat-value">{stats.days_active}</div>
              <div className="stat-label">Дней активно</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Profile;

