// Единственный справочник стандартных порций. Сопоставление только по полному названию.
export const PORTIONS = {
  garnish:{mass:150,hint:'Ориентировочная порция 150–200 г'},
  meat:{mass:150,hint:'Ориентировочная порция 100–200 г'},
  other:{mass:100,hint:'Начальная масса 100 г — укажите фактическую массу'},
};
export const PREPARATIONS = {raw:'Сырой продукт',cooked:'Приготовленный продукт',ready:'Готовый продукт / как на упаковке',other:'Другой способ — КБЖУ указаны вручную'};
const entries = [
  ...['Рис отварной','Рис бурый отварной','Гречка отварная','Макароны отварные','Спагетти отварные'].map(name=>[name,{category:'garnish',preparation:'cooked'}]),
  ...['Куриная грудка без кожи, приготовленная','Куриное бедро запечённое','Говядина приготовленная','Свинина приготовленная','Котлета куриная','Котлета мясная','Индейка приготовленная'].map(name=>[name,{category:'meat',preparation:'cooked'}]),
  ...['Рис сырой','Рис сухой','Гречка сухая','Макароны сухие','Морковь сырая','Брокколи сырая','Помидор','Огурец','Банан','Яблоко','Апельсин'].map(name=>[name,{category:'other',preparation:'raw'}]),
];
const normalize = name => String(name || '').trim().toLocaleLowerCase('ru').replaceAll('ё','е');
const foods = new Map(entries.map(([name,rule])=>[normalize(name),rule]));
export const foodRule = name => foods.get(normalize(name)) || {category:'other',preparation:''};
export const portionFor = name => PORTIONS[foodRule(name).category];
export function candidateItem(candidate, previous) {
  const rule=foodRule(candidate.name);
  return {name:candidate.name,estimated_mass:previous?.mass_edited ? previous.estimated_mass : portionFor(candidate.name).mass,
    mass_edited:Boolean(previous?.mass_edited),mass_confirmed:false,confidence:0,preparation:rule.preparation,
    portion_category:rule.category,source:candidate.source,source_url:candidate.source_url,
    nutrition_per_100g:Object.fromEntries(['calories','protein','fat','carbs'].map(k=>[k,candidate[k+'_per_100g']]))};
}
