import axios from 'axios';

const api = axios.create({
  baseURL: '/api',
  headers: {
    'Content-Type': 'application/json',
  },
});

// Поиск продуктов
export const searchFoods = async (query) => {
  const response = await api.get('/foods/search', { params: { query } });
  return response.data;
};

// Загрузка фото для распознавания
export const scanFood = async (file, mealType = 'lunch', cloud = false) => {
  const formData = new FormData();
  formData.append('file', file);

  const response = await api.post(`/scan?meal_type=${mealType}&cloud=${cloud}`, formData, {
    headers: { 'Content-Type': 'multipart/form-data' },
  });
  return response.data;
};

// История сканирований
export const getScans = async (limit = 20) => {
  const response = await api.get('/scans', { params: { limit } });
  return response.data;
};

// Детали скана
export const getScanDetail = async (id) => {
  const response = await api.get(`/scans/${id}`);
  return response.data;
};

export default api;
export const getFoodCatalog = async () => (await api.get('/foods/catalog')).data;

// Статистика за неделю
export const getWeeklyStats = async () => {
  const response = await api.get('/stats/weekly');
  return response.data;
};

// Общая статистика
export const getSummaryStats = async () => {
  const response = await api.get('/stats/summary');
  return response.data;
};

// Удалить скан
export const deleteScan = async (id) => {
  const response = await api.delete(`/scans/${id}`);
  return response.data;
};

// Профиль
export const getProfile = async () => {
  const response = await api.get('/profile');
  return response.data;
};

export const updateProfile = async (data) => {
  const response = await api.put('/profile', data);
  return response.data;
};

export const getProfileStats = async () => {
  const response = await api.get('/profile/stats');
  return response.data;
};

// Авторизация
export const register = async (data) => {
  const response = await api.post('/auth/register', data);
  return response.data;
};

export const login = async (data) => {
  const response = await api.post('/auth/login', data);
  return response.data;
};

export const getCurrentUser = async (token) => {
  const response = await api.get('/auth/me', {
    headers: { Authorization: `Bearer ${token}` },
  });
  return response.data;
};

// Добавляем токен в заголовки
api.interceptors.request.use((config) => {
  const token = localStorage.getItem('token');
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});

// Обработка ошибок
api.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response?.status === 401 && !['/auth/login', '/auth/register'].includes(error.config?.url)) {
      // Токен истек — выходим
      localStorage.removeItem('token');
      localStorage.removeItem('user');
      window.location.href = '/login';
    }
    return Promise.reject(error);
  }
);
export const saveMeal = async (data) => (await api.post("/scans", data)).data;
