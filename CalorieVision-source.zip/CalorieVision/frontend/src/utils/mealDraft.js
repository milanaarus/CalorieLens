const KEY = 'calorievision-meal-draft-v1';
const meals = ['breakfast','lunch','dinner','snack'];
export function clearMealDraft(storage = localStorage) {
  try { storage.removeItem(KEY); return true; } catch { return false; }
}
export function draftOwner(storage = localStorage) {
  try { const user = JSON.parse(storage.getItem('user') || 'null');
    return storage.getItem('token') && user ? String(user.id ?? user.email ?? '') : '';
  } catch { return ''; }
}
export function readMealDraft(storage = localStorage) {
  try {
    const draft = JSON.parse(storage.getItem(KEY) || 'null');
    if (!draft) return null;
    if (!draftOwner(storage) || draft.owner !== draftOwner(storage)) { clearMealDraft(storage); return null; }
    if (draft.version !== 1 || !meals.includes(draft.mealType) || !Array.isArray(draft.items) || !draft.items.length || draft.items.length > 50) { clearMealDraft(storage); return null; }
    return {...draft, items:draft.items.map(cleanItem)};
  } catch { clearMealDraft(storage); return null; }
}
function cleanItem(item) {
  const values = item?.nutrition_per_100g || {};
  const scalar = value => typeof value === 'string' || (typeof value === 'number' && Number.isFinite(value)) ? value : '';
  return {name:String(item?.name ?? '').slice(0,255), estimated_mass:scalar(item?.estimated_mass),
    confidence:0, preparation:['raw','cooked','ready','other'].includes(item?.preparation) ? item.preparation : '',
    portion_category:['garnish','meat','other'].includes(item?.portion_category) ? item.portion_category : undefined,
    mass_edited:Boolean(item?.mass_edited), mass_confirmed:false, nutrition_missing:Boolean(item?.nutrition_missing),
    nutrition_per_100g:Object.fromEntries(['calories','protein','fat','carbs'].map(k=>[k,scalar(values[k])])),
    source:'Восстановлено из черновика — проверьте данные'};
}
export function writeMealDraft(items, mealType, storage = localStorage) {
  const owner = draftOwner(storage);
  if (!owner) return false;
  if (!items.length) return clearMealDraft(storage);
  try {
    storage.setItem(KEY,JSON.stringify({version:1,owner,mealType,items:items.slice(0,50).map(cleanItem)}));
    return true;
  } catch { return false; }
}
