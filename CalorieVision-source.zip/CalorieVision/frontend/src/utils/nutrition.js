export const NUTRIENT_LIMITS = {calories:1000, protein:100, fat:100, carbs:100};
export const emptyNutrition = () => ({calories:'', protein:'', fat:'', carbs:''});
export function completeValues(nutrition) {
  return Object.entries(NUTRIENT_LIMITS).every(([key,max]) => {
    const value=nutrition?.[key];
    return value !== '' && value !== null && value !== undefined &&
      Number.isFinite(Number(value)) && Number(value)>=0 && Number(value)<=max;
  });
}
export const hasNutrition = item => !item.nutrition_missing && completeValues(item.nutrition_per_100g);
export function prepareItem(item) {
  return {...item, nutrition_per_100g:item.nutrition_missing ? emptyNutrition() : {...emptyNutrition(),...item.nutrition_per_100g}};
}
export function mealTotals(items) {
  if (!items.length || items.some(item=>!hasNutrition(item) || !Number.isFinite(Number(item.estimated_mass)) || Number(item.estimated_mass)<=0)) return null;
  return items.reduce((total,item)=>{
    for(const key of Object.keys(NUTRIENT_LIMITS)) total[key]+=Number(item.nutrition_per_100g[key])*Number(item.estimated_mass)/100;
    return total;
  },{calories:0,protein:0,fat:0,carbs:0});
}
