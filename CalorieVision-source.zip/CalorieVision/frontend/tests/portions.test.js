import test from 'node:test';
import assert from 'node:assert/strict';
import {portionFor,foodRule,candidateItem} from '../src/config/portions.js';
import {mealTotals} from '../src/utils/nutrition.js';
import {writeMealDraft,readMealDraft,clearMealDraft} from '../src/utils/mealDraft.js';
test('exact food mapping distinguishes cooked rice from unknown and raw',()=>{
 assert.equal(portionFor('Рис отварной').mass,150); assert.equal(portionFor('Гречка отварная').mass,150);
 assert.equal(portionFor('Куриная грудка без кожи, приготовленная').mass,150);
 assert.equal(portionFor('Котлета мясная').mass,150);assert.equal(portionFor('Рис сырой').mass,100);
 assert.equal(foodRule('Бренд рис отварной с соусом').preparation,'');
});
test('new portion is suggested but an edited mass survives replacement',()=>{
 assert.equal(candidateItem({name:'Рис отварной'}).estimated_mass,150);
 assert.equal(candidateItem({name:'Рис отварной'},{mass_edited:true,estimated_mass:235}).estimated_mass,235);
});
test('sum uses full precision and becomes incomplete when a nutrient or mass is missing',()=>{
 const item={estimated_mass:1,nutrition_per_100g:{calories:3.4,protein:1,fat:0,carbs:1}};
 assert.equal(mealTotals([item,item,item]).calories,0.10200000000000001);
 assert.equal(mealTotals([item,{...item,estimated_mass:''}]),null);
 assert.equal(mealTotals([item,{...item,nutrition_missing:true}]),null);
});
test('draft preserves cooking and mass without photo and is isolated by account',()=>{
 const data=new Map([['user',JSON.stringify({id:1})],['token','test']]);
 const storage={getItem:k=>data.get(k)??null,setItem:(k,v)=>data.set(k,v),removeItem:k=>data.delete(k)};
 writeMealDraft([{name:'Рис отварной',estimated_mass:235,mass_edited:true,preparation:'cooked',preview:'private-photo'}],'dinner',storage);
 assert.equal(readMealDraft(storage).items[0].estimated_mass,235);
 assert.equal(readMealDraft(storage).items[0].preparation,'cooked');
 assert.equal(JSON.stringify(readMealDraft(storage)).includes('private-photo'),false);
 data.set('user',JSON.stringify({id:2}));assert.equal(readMealDraft(storage),null);
 assert.equal(clearMealDraft(storage),true);
});
