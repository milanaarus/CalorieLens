import test from 'node:test';
import assert from 'node:assert/strict';
import {emptyNutrition,prepareItem,hasNutrition,mealTotals} from '../src/utils/nutrition.js';
const pizza={name:'Pizza',estimated_mass:150,nutrition_per_100g:{calories:256,protein:12,fat:8.56,carbs:31.7}};
test('unknown zero placeholders become empty inputs and no totals',()=>{
 const unknown=prepareItem({...pizza,nutrition_missing:true,nutrition_per_100g:{calories:0,protein:0,fat:0,carbs:0}});
 assert.deepEqual(unknown.nutrition_per_100g,emptyNutrition());assert.equal(hasNutrition(unknown),false);
 assert.equal(mealTotals([pizza,unknown]),null);
});
test('clearing even one macro prevents a complete result',()=>{
 for(const value of ['',null,undefined,NaN,-1]) {
  const item={...pizza,nutrition_per_100g:{...pizza.nutrition_per_100g,fat:value}};
  assert.equal(hasNutrition(item),false);assert.equal(mealTotals([item]),null);
 }
});
test('explicit zero is valid and selected 150g portion yields 384 kcal',()=>{
 assert.equal(mealTotals([pizza]).calories,384);
 assert.equal(mealTotals([{...pizza,nutrition_per_100g:{calories:0,protein:0,fat:0,carbs:0}}]).calories,0);
 assert.equal(mealTotals([]),null);
});
