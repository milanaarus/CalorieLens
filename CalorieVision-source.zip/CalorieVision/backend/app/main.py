from fastapi import FastAPI, Query, Depends, UploadFile, File
from fastapi.middleware.cors import CORSMiddleware
from fastapi import HTTPException, Header
from sqlalchemy import text
from sqlalchemy.orm import Session
from sqlalchemy import func
from typing import Literal

from app.core.database import get_db
from app.services.nutrition_service import nutrition_service
from app.services.cv_service import cv_service
from app.services.food_catalog import CATALOG
import asyncio
from app.services.calorie_service import calorie_service
from app.models.scan import Scan, DetectedFood
from datetime import datetime, timedelta
from app.models.user import User
from app.core.security import hash_password, verify_password, create_access_token, decode_token
from pydantic import BaseModel, Field, field_validator
import re


app = FastAPI(title="CalVision API", version="1.0.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:5173"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


def require_user(authorization: str = Header(None), db: Session = Depends(get_db)):
    if not authorization or not authorization.startswith("Bearer "):
        raise HTTPException(status_code=401, detail="Войдите в личный кабинет")
    payload = decode_token(authorization[7:])
    try:
        user_id = int(payload["sub"])
    except (TypeError, ValueError, KeyError):
        raise HTTPException(status_code=401, detail="Неверный токен")
    user = db.query(User).filter(User.id == user_id).first()
    if not user:
        raise HTTPException(status_code=401, detail="Пользователь не найден")
    return user


@app.get("/")
async def root():
    return {"message": "CalVision API is running!"}


@app.get("/health")
async def health_check():
    return {"status": "ok"}


@app.get("/api/db/health")
async def db_health_check(db: Session = Depends(get_db)):
    try:
        db.execute(text("SELECT 1"))
        return {"database": "connected"}
    except Exception as e:
        return {"database": "error", "detail": str(e)}


@app.get("/api/foods/search")
async def search_foods(query: str = Query(..., min_length=2, max_length=120), remote: bool = False, user: User = Depends(require_user)):
    result = await nutrition_service.search_food(query, allow_remote=remote)
    if not result:
        return {"found": False, "message": f"Продукт '{query}' не найден"}
    return {"found": True, "product": result}


@app.post("/api/scan")
async def scan_food(
    file: UploadFile = File(...),
    meal_type: Literal["breakfast", "lunch", "dinner", "snack"] = "lunch",
    user: User = Depends(require_user)
):
    """
    Загружает фото и возвращает предварительный расчёт без сохранения.
    """
    # Читаем изображение
    if file.content_type not in {"image/jpeg", "image/png", "image/webp"}:
        raise HTTPException(status_code=415, detail="Используйте JPEG, PNG или WebP")
    image_bytes = await file.read(10 * 1024 * 1024 + 1)
    if len(image_bytes) > 10 * 1024 * 1024:
        raise HTTPException(status_code=413, detail="Максимальный размер фото — 10 МБ")

    # Распознаем продукты
    try:
        detected = await cv_service.detect_food(image_bytes)
    except (OSError, ValueError):
        raise HTTPException(status_code=400, detail="Не удалось прочитать изображение")
    except RuntimeError:
        raise HTTPException(status_code=503, detail="Распознавание недоступно. Попробуйте позже или добавьте состав из каталога.")

    if not detected:
        return {
            "success": False,
            "message": "Не удалось распознать продукты на фото",
            "detected": []
        }

    # Для каждого продукта считаем калории
    items = []
    async def lookup(name):
        try:
            return await asyncio.wait_for(nutrition_service.search_food(name, allow_remote=False), timeout=8)
        except asyncio.TimeoutError:
            return None
    nutrients = await asyncio.gather(*(lookup(item['name']) for item in detected))
    for item, nutrition in zip(detected, nutrients):
        if not nutrition:
            items.append({**item, 'nutrition_per_100g': dict(calories=0, protein=0, fat=0, carbs=0),
                          'nutrition_missing': True, 'source': 'Нет данных — заполните КБЖУ',
                          'calories': 0, 'protein': 0, 'fat': 0, 'carbs': 0})
            continue

        if nutrition:
            mass = item["estimated_mass"]
            macros = calorie_service.calculate_for_item(nutrition, mass)

            items.append({
                "recognition_method": item.get('recognition_method', 'local'),
                "source_url": nutrition.get('source_url'),
                "nutrition_per_100g": {k: nutrition.get(k + "_per_100g", 0) for k in ("calories", "protein", "fat", "carbs")},
                "name": nutrition["name"],
                "source": nutrition.get("source"),
                "confidence": item["confidence"],
                "estimated_mass": mass,
                "calories": macros["calories"],
                "protein": macros["protein"],
                "fat": macros["fat"],
                "carbs": macros["carbs"],
            })

    # Считаем итоги
    totals = calorie_service.calculate_total(items)

    if not items:
        return {"success": False, "message": "Для распознанных продуктов не найдены данные о питании. Добавьте состав вручную."}
    return {"success": True, "meal_type": meal_type, **totals, "items": items}


@app.get('/api/foods/catalog')
async def food_catalog(user: User = Depends(require_user)):
    return {'foods': [{**f, 'local': nutrition_service.has_local(f['name'])} for f in CATALOG], 'count': len(CATALOG), 'local_count': len({v['fdc_id'] for v in nutrition_service.reference.values()}), 'cloud_available': False}


class NutritionInput(BaseModel):
    calories: float = Field(ge=0, le=1000, allow_inf_nan=False)
    protein: float = Field(default=0, ge=0, le=100, allow_inf_nan=False)
    fat: float = Field(default=0, ge=0, le=100, allow_inf_nan=False)
    carbs: float = Field(default=0, ge=0, le=100, allow_inf_nan=False)


class MealItemInput(BaseModel):
    name: str = Field(min_length=1, max_length=255)
    estimated_mass: float = Field(gt=0, le=3000, allow_inf_nan=False)
    confidence: float = Field(default=0, ge=0, le=1, allow_inf_nan=False)
    nutrition_per_100g: NutritionInput


class MealInput(BaseModel):
    meal_type: Literal["breakfast", "lunch", "dinner", "snack"] = "lunch"
    items: list[MealItemInput] = Field(min_length=1, max_length=50)


@app.post("/api/scans")
async def save_meal(data: MealInput, db: Session = Depends(get_db), user: User = Depends(require_user)):
    items = []
    for item in data.items:
        n = item.nutrition_per_100g
        macros = calorie_service.calculate_for_item({
            k + "_per_100g": getattr(n, k) for k in ("calories", "protein", "fat", "carbs")
        }, item.estimated_mass)
        items.append({"name": item.name.strip(), "estimated_mass": item.estimated_mass,
                      "confidence": item.confidence, **macros})
    if any(not item["name"] for item in items):
        raise HTTPException(status_code=422, detail="Укажите название каждого продукта")
    totals = calorie_service.calculate_total(items)
    scan = Scan(user_id=user.id, meal_type=data.meal_type, **totals,
                confidence=sum(i["confidence"] for i in items) / len(items))
    db.add(scan)
    db.flush()
    for item in items:
        db.add(DetectedFood(scan_id=scan.id, **item))
    db.commit()
    return {"success": True, "scan_id": scan.id, **totals}


@app.get("/api/scans")
async def get_scans(
    limit: int = Query(20, ge=1, le=100),
    db: Session = Depends(get_db), user: User = Depends(require_user)
):
    """
    Возвращает историю сканирований
    """
    scans = db.query(Scan).filter(Scan.user_id == user.id).order_by(Scan.created_at.desc()).limit(limit).all()

    return {
        "total": len(scans),
        "scans": [
            {
                "id": s.id,
                "meal_type": s.meal_type,
                "total_calories": s.total_calories,
                "total_protein": s.total_protein,
                "total_fat": s.total_fat,
                "total_carbs": s.total_carbs,
                "confidence": s.confidence,
                "created_at": s.created_at.isoformat() if s.created_at else None,
            }
            for s in scans
        ]
    }


@app.get("/api/scans/{scan_id}")
async def get_scan_detail(scan_id: int, db: Session = Depends(get_db), user: User = Depends(require_user)):
    """
    Возвращает детали конкретного скана
    """
    scan = db.query(Scan).filter(Scan.user_id == user.id).filter(Scan.id == scan_id).first()

    if not scan:
        raise HTTPException(status_code=404, detail="Скан не найден")

    items = db.query(DetectedFood).filter(DetectedFood.scan_id == scan_id).all()

    return {
        "success": True,
        "scan": {
            "id": scan.id,
            "meal_type": scan.meal_type,
            "total_calories": scan.total_calories,
            "total_protein": scan.total_protein,
            "total_fat": scan.total_fat,
            "total_carbs": scan.total_carbs,
            "created_at": scan.created_at.isoformat() if scan.created_at else None,
            "items": [
                {
                    "name": item.name,
                    "confidence": item.confidence,
                    "estimated_mass": item.estimated_mass,
                    "calories": item.calories,
                    "protein": item.protein,
                    "fat": item.fat,
                    "carbs": item.carbs,
                }
                for item in items
            ]
        }
    }


@app.get("/api/stats/weekly")
async def get_weekly_stats(db: Session = Depends(get_db), user: User = Depends(require_user)):
    """
    Возвращает статистику за последние 7 дней
    """
    today = datetime.now().date()
    week_ago = today - timedelta(days=6)

    # Получаем все сканы за неделю
    scans = db.query(Scan).filter(Scan.user_id == user.id).filter(
        func.date(Scan.created_at) >= week_ago
    ).all()

    # Группируем по дням
    days = []
    for i in range(7):
        day = week_ago + timedelta(days=i)
        day_scans = [
            s for s in scans
            if s.created_at and s.created_at.date() == day
        ]

        days.append({
            "date": day.isoformat(),
            "day_name": day.strftime("%a"),
            "total_calories": round(sum(s.total_calories for s in day_scans), 1),
            "total_protein": round(sum(s.total_protein for s in day_scans), 1),
            "total_fat": round(sum(s.total_fat for s in day_scans), 1),
            "total_carbs": round(sum(s.total_carbs for s in day_scans), 1),
            "meals_count": len(day_scans),
        })

    return {"days": days}


@app.get("/api/stats/summary")
async def get_summary_stats(db: Session = Depends(get_db), user: User = Depends(require_user)):
    """
    Общая статистика: сегодня, за неделю, за месяц
    """
    today = datetime.now().date()
    week_ago = today - timedelta(days=6)
    month_ago = today - timedelta(days=29)

    all_scans = db.query(Scan).filter(Scan.user_id == user.id).all()

    def sum_for_period(scans_list):
        return {
            "calories": round(sum(s.total_calories for s in scans_list), 1),
            "protein": round(sum(s.total_protein for s in scans_list), 1),
            "fat": round(sum(s.total_fat for s in scans_list), 1),
            "carbs": round(sum(s.total_carbs for s in scans_list), 1),
            "count": len(scans_list),
        }

    today_scans = [s for s in all_scans if s.created_at and s.created_at.date() == today]
    week_scans = [s for s in all_scans if s.created_at and s.created_at.date() >= week_ago]
    month_scans = [s for s in all_scans if s.created_at and s.created_at.date() >= month_ago]

    return {
        "today": sum_for_period(today_scans),
        "week": sum_for_period(week_scans),
        "month": sum_for_period(month_scans),
        "total": sum_for_period(all_scans),
    }


@app.delete("/api/scans/{scan_id}")
async def delete_scan(scan_id: int, db: Session = Depends(get_db), user: User = Depends(require_user)):
    """
    Удаляет скан
    """
    scan = db.query(Scan).filter(Scan.user_id == user.id).filter(Scan.id == scan_id).first()
    if not scan:
        raise HTTPException(status_code=404, detail="Скан не найден")

    db.query(DetectedFood).filter(DetectedFood.scan_id == scan.id).delete()
    db.delete(scan)
    db.commit()
    return {"success": True, "message": "Скан удалён"}


class ProfileUpdate(BaseModel):
    name: str | None = Field(default=None, min_length=1, max_length=100)
    weight: float | None = Field(default=None, gt=0, le=1000, allow_inf_nan=False)
    height: float | None = Field(default=None, gt=0, le=300, allow_inf_nan=False)
    age: int | None = Field(default=None, ge=1, le=120)
    daily_calorie_goal: float | None = Field(default=None, gt=0, le=20000, allow_inf_nan=False)
    activity_level: str | None = Field(default=None, max_length=30)


@app.get("/api/profile")
async def get_profile(db: Session = Depends(get_db), user: User = Depends(require_user)):
    """
    Возвращает профиль авторизованного пользователя.
    """


    return {
        "id": user.id,
        "email": user.email,
        "name": user.name,
        "weight": user.weight,
        "height": user.height,
        "age": user.age,
        "daily_calorie_goal": user.daily_calorie_goal,
        "activity_level": user.activity_level,
    }


@app.put("/api/profile")
async def update_profile(
    profile: ProfileUpdate,
    db: Session = Depends(get_db), user: User = Depends(require_user)
):
    """
    Обновляет профиль пользователя
    """

    if not user:
        return {"success": False, "message": "Пользователь не найден"}

    if profile.name is not None:
        user.name = profile.name
    if profile.weight is not None:
        user.weight = profile.weight
    if profile.height is not None:
        user.height = profile.height
    if profile.age is not None:
        user.age = profile.age
    if profile.daily_calorie_goal is not None:
        user.daily_calorie_goal = profile.daily_calorie_goal
    if profile.activity_level is not None:
        user.activity_level = profile.activity_level

    db.commit()
    db.refresh(user)

    return {
        "success": True,
        "profile": {
            "id": user.id,
            "name": user.name,
            "weight": user.weight,
            "height": user.height,
            "age": user.age,
            "daily_calorie_goal": user.daily_calorie_goal,
            "activity_level": user.activity_level,
        }
    }


@app.get("/api/profile/stats")
async def get_profile_stats(db: Session = Depends(get_db), user: User = Depends(require_user)):
    """
    Статистика пользователя за всё время
    """
    scans = db.query(Scan).filter(Scan.user_id == user.id).all()

    if not scans:
        return {
            "total_scans": 0,
            "total_calories": 0,
            "avg_calories_per_scan": 0,
            "avg_calories_per_day": 0,
        }

    total_calories = sum(s.total_calories for s in scans)

    # Уникальные дни
    days = set()
    for s in scans:
        if s.created_at:
            days.add(s.created_at.date())

    return {
        "total_scans": len(scans),
        "total_calories": round(total_calories, 1),
        "avg_calories_per_scan": round(total_calories / len(scans), 1) if scans else 0,
        "avg_calories_per_day": round(total_calories / len(days), 1) if days else 0,
        "days_active": len(days),
    }


class EmailRequest(BaseModel):
    email: str = Field(max_length=254)

    @field_validator("email")
    @classmethod
    def normalize_email(cls, value):
        value = value.strip().casefold()
        if not re.fullmatch(r"[^\s@]+@[^\s@]+\.[^\s@]+", value):
            raise ValueError("Укажите адрес почты в формате name@example.com")
        return value


class RegisterRequest(EmailRequest):
    password: str
    name: str


class LoginRequest(EmailRequest):
    password: str


@app.post("/api/auth/register")
async def register(data: RegisterRequest, db: Session = Depends(get_db)):
    """
    Регистрация нового пользователя
    """
    # Проверяем, есть ли уже такой email
    existing = db.query(User).filter(func.lower(User.email) == data.email).first()
    if existing:
        raise HTTPException(status_code=400, detail="Email уже зарегистрирован")

    # Создаем пользователя
    user = User(
        email=data.email,
        hashed_password=hash_password(data.password),
        name=data.name,
        weight=70.0,
        height=170.0,
        age=25,
        daily_calorie_goal=2200.0,
        activity_level="moderate",
    )
    db.add(user)
    db.commit()
    db.refresh(user)

    # Создаем токен
    token = create_access_token({"sub": str(user.id), "email": user.email})

    return {
        "success": True,
        "token": token,
        "user": {
            "id": user.id,
            "email": user.email,
            "name": user.name,
        }
    }


@app.post("/api/auth/login")
async def login(data: LoginRequest, db: Session = Depends(get_db)):
    """
    Вход в систему
    """
    user = db.query(User).filter(func.lower(User.email) == data.email).first()
    if not user:
        raise HTTPException(status_code=401, detail="Неверный email или пароль")

    if not verify_password(data.password, user.hashed_password):
        raise HTTPException(status_code=401, detail="Неверный email или пароль")

    token = create_access_token({"sub": str(user.id), "email": user.email})

    return {
        "success": True,
        "token": token,
        "user": {
            "id": user.id,
            "email": user.email,
            "name": user.name,
        }
    }


@app.get("/api/auth/me")
async def get_current_user(
    authorization: str = Header(None),
    db: Session = Depends(get_db)
):
    """
    Возвращает текущего пользователя по токену
    """
    if not authorization or not authorization.startswith("Bearer "):
        raise HTTPException(status_code=401, detail="Не авторизован")

    token = authorization.replace("Bearer ", "")
    payload = decode_token(token)

    if not payload:
        raise HTTPException(status_code=401, detail="Неверный токен")

    user = db.query(User).filter(User.id == int(payload["sub"])).first()
    if not user:
        raise HTTPException(status_code=404, detail="Пользователь не найден")

    return {
        "id": user.id,
        "email": user.email,
        "name": user.name,
        "weight": user.weight,
        "height": user.height,
        "age": user.age,
        "daily_calorie_goal": user.daily_calorie_goal,
        "activity_level": user.activity_level,
    }
