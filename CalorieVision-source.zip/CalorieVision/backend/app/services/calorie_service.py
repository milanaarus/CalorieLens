from typing import Dict, Any, Optional


class CalorieService:
    """
    Сервис для расчета калорийности и БЖУ
    """

    def calculate_for_item(
        self,
        nutrition: Dict[str, Any],
        mass: float
    ) -> Dict[str, float]:
        """
        Рассчитывает калории и БЖУ для продукта заданной массы
        """
        factor = mass / 100.0

        return {
            "calories": round(nutrition.get("calories_per_100g", 0) * factor, 1),
            "protein": round(nutrition.get("protein_per_100g", 0) * factor, 1),
            "fat": round(nutrition.get("fat_per_100g", 0) * factor, 1),
            "carbs": round(nutrition.get("carbs_per_100g", 0) * factor, 1),
        }

    def calculate_total(self, items: list) -> Dict[str, float]:
        """
        Считает итоговые калории и БЖУ для всего блюда
        """
        total = {"calories": 0, "protein": 0, "fat": 0, "carbs": 0}

        for item in items:
            total["calories"] += item.get("calories", 0)
            total["protein"] += item.get("protein", 0)
            total["fat"] += item.get("fat", 0)
            total["carbs"] += item.get("carbs", 0)

        return {
            "total_calories": round(total["calories"], 1),
            "total_protein": round(total["protein"], 1),
            "total_fat": round(total["fat"], 1),
            "total_carbs": round(total["carbs"], 1),
        }


calorie_service = CalorieService()
