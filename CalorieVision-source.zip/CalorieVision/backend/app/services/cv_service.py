from PIL import Image, ImageOps
import io
from typing import List, Dict, Any
from pathlib import Path
from starlette.concurrency import run_in_threadpool
from threading import Lock
import os


class CVService:
    def __init__(self):
        self.model = None
        self.lock = Lock()

        # Расширенный маппинг классов YOLO → продукты
        self.food_classes = {
            # Фрукты
            "banana": {"name": "banana", "default_mass": 120},
            "apple": {"name": "apple", "default_mass": 180},
            "orange": {"name": "orange", "default_mass": 150},

            # Овощи
            "broccoli": {"name": "broccoli", "default_mass": 150},
            "carrot": {"name": "carrot", "default_mass": 80},

            # Готовые блюда
            "sandwich": {"name": "sandwich", "default_mass": 200},
            "pizza": {"name": "pizza", "default_mass": 250},
            "hot dog": {"name": "hot dog", "default_mass": 150},
            "donut": {"name": "donut", "default_mass": 70},
            "cake": {"name": "cake", "default_mass": 120},


}

    async def detect_food(self, image_bytes: bytes) -> List[Dict[str, Any]]:
        # Keep health checks and other requests responsive during CPU inference.
        return await run_in_threadpool(self._detect_serial, image_bytes)

    def _detect_serial(self, image_bytes):
        # Model initialization/inference must not run concurrently on a small host.
        with self.lock:
            return self._detect_food(image_bytes)

    def _detect_food(self, image_bytes):
        """
        Распознает продукты на изображении и оценивает массу
        """
        image = Image.open(io.BytesIO(image_bytes))
        if image.width * image.height > 12_000_000:
            raise ValueError("Image resolution is too large")
        image = ImageOps.exif_transpose(image).convert("RGB")
        image.thumbnail((1600, 1600))
        if self.model is None:
            try:
                from ultralytics import YOLO
            except ImportError as exc:
                raise RuntimeError("Для распознавания установите ultralytics. Ручной ввод доступен.") from exc
            self.model = YOLO(str(Path(__file__).resolve().parents[2] / "yolov8n.pt"))
        image_size = max(160, min(640, int(os.getenv('CV_IMAGE_SIZE', '640'))))
        results = self.model(image, imgsz=image_size, device='cpu', verbose=False)

        detected = []
        for result in results:
            for box in result.boxes:
                class_id = int(box.cls[0])
                class_name = self.model.names[class_id]
                confidence = float(box.conf[0])

                if class_name in self.food_classes and confidence > 0.3:
                    food_info = self.food_classes[class_name]

                    # Масса — начальная порция, которую пользователь уточняет.
                    # Площадь объекта не даёт массу без масштаба и глубины.
                    estimated_mass = food_info["default_mass"]

                    detected.append({
                        "name": food_info["name"],
                        "original_class": class_name,
                        "confidence": round(confidence, 3),
                        "estimated_mass": estimated_mass,
                        "bbox": [round(x, 2) for x in box.xyxy[0].tolist()]
                    })

        return detected


cv_service = CVService()
