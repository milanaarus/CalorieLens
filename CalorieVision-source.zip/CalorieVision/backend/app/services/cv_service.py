"""Photo validation and serialized CPU food inference."""
from PIL import Image, ImageOps
import io
from threading import Lock
from starlette.concurrency import run_in_threadpool


class CVService:
    def __init__(self):
        self.model = None
        self.lock = Lock()

    async def detect_food(self, image_bytes):
        return await run_in_threadpool(self._detect_serial, image_bytes)

    def _detect_serial(self, image_bytes):
        with self.lock:
            return self._detect_food(image_bytes)

    def _detect_food(self, image_bytes):
        with Image.open(io.BytesIO(image_bytes)) as source:
            if source.width * source.height > 12_000_000:
                raise ValueError('Image resolution is too large')
            image = ImageOps.exif_transpose(source).convert('RGB')
        image.thumbnail((1600, 1600))
        if self.model is None:
            try:
                from app.services.onnx_food import FoodDetector
                self.model = FoodDetector()
            except Exception as exc:
                raise RuntimeError('Food models unavailable') from exc
        try:
            return self.model.detect(image)
        except Exception as exc:
            raise RuntimeError('Food inference failed') from exc


cv_service = CVService()
