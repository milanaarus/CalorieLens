from PIL import Image, ImageOps
import io
from typing import List, Dict, Any
from pathlib import Path


class CVService:
    def __init__(self):
        self.model = None

        # Расширенный маппинг классов YOLO → продукты
        self.food_classes = {
            # Фрукты
            "banana": {"name": "banana", "default_mass": 120},
            "apple": {"name": "apple", "default_mass": 180},
            "orange": {"name": "orange", "default_mass": 150},

            # Овощи
            "broccoli": {"name": "broccoli", "default_mass": 150},
            "carrot": {"name": "carrot", "default_mass": 80},

            # Готовые блюда
            "sandwich": {"name": "sandwich", "default_mass": 200},
            "pizza": {"name": "pizza", "default_mass": 250},
            "hot dog": {"name": "hot dog", "default_mass": 150},
            "donut": {"name": "donut", "default_mass": 70},
            "cake": {"name": "cake", "default_mass": 120},


}

    async def detect_food(self, image_bytes: bytes) -> List[Dict[str, Any]]:
        """
        Распознает продукты на изображении и оценивает массу
        """
        image = ImageOps.exif_transpose(Image.open(io.BytesIO(image_bytes))).convert("RGB")
        image.thumbnail((1600, 1600))
        if self.model is None:
            try:
                from ultralytics import YOLO
            except ImportError as exc:
                raise RuntimeError("Для распознавания установите ultralytics. Ручной ввод доступен.") from exc
            self.model = YOLO(str(Path(__file__).resolve().parents[2] / "yolov8n.pt"))
        results = self.model(image)

        detected = []
        for result in results:
            for box in result.boxes:
                class_id = int(box.cls[0])
                class_name = self.model.names[class_id]
                confidence = float(box.conf[0])

                if class_name in self.food_classes and confidence > 0.3:
                    food_info = self.food_classes[class_name]

                    # Масса — начальная порция, которую пользователь уточняет.
                    # Площадь объекта не даёт массу без масштаба и глубины.
                    estimated_mass = food_info["default_mass"]

                    detected.append({
                        "name": food_info["name"],
                        "original_class": class_name,
                        "confidence": round(confidence, 3),
                        "estimated_mass": estimated_mass,
                        "bbox": [round(x, 2) for x in box.xyxy[0].tolist()]
                    })

        return detected


cv_service = CVService()
