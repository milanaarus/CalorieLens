"""Small reference + bounded persistent cache + remote APIs.

Reference values are approximate starter values, not a campus menu or
verified recipe cards. A user reviews the selected food before saving.
"""
import asyncio
import json
import os
import sqlite3
import time
from pathlib import Path
from contextlib import closing
from app.services.openfoodfacts_service import openfoodfacts_service
from app.services.usda_service import usda_service
from app.services.food_catalog import find_food

# Small, source-attributed snapshot: no network needed for core calculations.
REFERENCE = json.loads(Path(__file__).with_name('core_foods.json').read_text(encoding='utf-8'))

def normalize(query):
    return ' '.join(query.casefold().replace('ё', 'е').split())[:120]


class NutritionService:
    TTL = 7 * 24 * 3600
    MAX_ENTRIES = 1000

    def __init__(self):
        self.path = Path(os.getenv("NUTRITION_CACHE_PATH", "data/nutrition-cache.sqlite3"))
        self.reference = {}
        self.lock = asyncio.Lock()
        self.failed = {}
        for value in REFERENCE:
            food = find_food(value['name'])
            for alias in [value['name'], value['description'], food['query'] if food else '']:
                if alias:
                    self.reference[normalize(alias)] = value

    def has_local(self, name):
        return normalize(name) in self.reference

    def connect(self):
        self.path.parent.mkdir(parents=True, exist_ok=True)
        db = sqlite3.connect(self.path, timeout=3)
        db.execute("CREATE TABLE IF NOT EXISTS nutrients (query TEXT PRIMARY KEY, payload TEXT, expires REAL)")
        return db

    def cached(self, query):
        with closing(self.connect()) as db:
            row = db.execute("SELECT payload FROM nutrients WHERE query=? AND expires>?", (query, time.time())).fetchone()
        return json.loads(row[0]) if row else None

    def store(self, query, value):
        with closing(self.connect()) as db:
            db.execute("DELETE FROM nutrients WHERE expires<=?", (time.time(),))
            db.execute("INSERT OR REPLACE INTO nutrients VALUES (?, ?, ?)",
                       (query, json.dumps(value, ensure_ascii=False), time.time() + self.TTL))
            db.execute("DELETE FROM nutrients WHERE query IN (SELECT query FROM nutrients ORDER BY expires DESC LIMIT -1 OFFSET ?)", (self.MAX_ENTRIES,))
            db.commit()

    async def search_choices(self, query, allow_remote=True):
        original = normalize(query)
        local = self.reference.get(original)
        if local:
            return [dict(local)]
        if not allow_remote:
            return []
        aliases = {'пицца (уточните состав)': 'pizza', 'сэндвич': 'sandwich'}
        food = find_food(original)
        query = food['query'] if food else aliases.get(original, original)
        cache_key = 'choices-v1:' + query
        async with self.lock:
            cached = self.cached(cache_key)
            if cached:
                return [{**value, 'cached': True} for value in cached]
            products = await openfoodfacts_service.search_products(query)
            if not products:
                value = await usda_service.search_product(query)
                products = [value] if value else []
            if products:
                self.store(cache_key, products)
            return products

    async def search_food(self, query, allow_remote=True):
        query = normalize(query)
        if query in self.reference:
            return dict(self.reference[query])
        if not allow_remote:
            return None
        food = find_food(query)
        if food:
            query = food['query']
        async with self.lock:
            cached = self.cached(query)
            if cached:
                return {**cached, "cached": True}
            now = time.time()
            self.failed = {k: v for k, v in self.failed.items() if v > now}
            if query in self.failed:
                return None
            value = await usda_service.search_product(query)
            if not value:
                value = await openfoodfacts_service.search_product(query)
            if value:
                self.store(query, value)
            else:
                if len(self.failed) >= self.MAX_ENTRIES:
                    self.failed.clear()
                self.failed[query] = now + 60
            return value


nutrition_service = NutritionService()
