"""Small reference + bounded persistent cache + remote APIs.

Reference values are approximate starter values, not a campus menu or
verified recipe cards. A user reviews the selected food before saving.
"""
import asyncio
import json
import os
import sqlite3
import time
from pathlib import Path
from contextlib import closing
from app.services.openfoodfacts_service import openfoodfacts_service
from app.services.usda_service import usda_service

# name, English alias, kcal/protein/fat/carbs per 100 g.
REFERENCE = [
    ("Банан", "banana", 89, 1.1, .3, 22.8),
    ("Яблоко", "apple", 52, .3, .2, 13.8),
    ("Апельсин", "orange", 47, .9, .1, 11.8),
    ("Брокколи сырая", "broccoli", 34, 2.8, .4, 6.6),
    ("Морковь сырая", "carrot", 41, .9, .2, 9.6),
    ("Помидор", "tomato", 18, .9, .2, 3.9),
    ("Огурец", "cucumber", 15, .7, .1, 3.6),
    ("Рис отварной", "cooked rice", 130, 2.7, .3, 28),
    ("Куриная грудка без кожи, приготовленная", "cooked chicken breast", 165, 31, 3.6, 0),
    ("Оливковое масло", "olive oil", 884, 0, 100, 0),
]


class NutritionService:
    TTL = 7 * 24 * 3600
    MAX_ENTRIES = 1000

    def __init__(self):
        self.path = Path(os.getenv("NUTRITION_CACHE_PATH", "data/nutrition-cache.sqlite3"))
        self.reference = {}
        self.lock = asyncio.Lock()
        self.failed = {}
        for name, alias, kcal, protein, fat, carbs in REFERENCE:
            value = {"name": name, "calories_per_100g": kcal, "protein_per_100g": protein,
                     "fat_per_100g": fat, "carbs_per_100g": carbs,
                     "source": "Приблизительный справочник", "needs_review": True}
            self.reference[name.casefold()] = value
            self.reference[alias] = value

    def connect(self):
        self.path.parent.mkdir(parents=True, exist_ok=True)
        db = sqlite3.connect(self.path, timeout=3)
        db.execute("CREATE TABLE IF NOT EXISTS nutrients (query TEXT PRIMARY KEY, payload TEXT, expires REAL)")
        return db

    def cached(self, query):
        with closing(self.connect()) as db:
            row = db.execute("SELECT payload FROM nutrients WHERE query=? AND expires>?", (query, time.time())).fetchone()
        return json.loads(row[0]) if row else None

    def store(self, query, value):
        with closing(self.connect()) as db:
            db.execute("DELETE FROM nutrients WHERE expires<=?", (time.time(),))
            db.execute("INSERT OR REPLACE INTO nutrients VALUES (?, ?, ?)",
                       (query, json.dumps(value, ensure_ascii=False), time.time() + self.TTL))
            db.execute("DELETE FROM nutrients WHERE query IN (SELECT query FROM nutrients ORDER BY expires DESC LIMIT -1 OFFSET ?)", (self.MAX_ENTRIES,))
            db.commit()

    async def search_food(self, query, allow_remote=True):
        query = " ".join(query.casefold().split())[:120]
        if query in self.reference:
            return dict(self.reference[query])
        if not allow_remote:
            return None
        async with self.lock:
            cached = self.cached(query)
            if cached:
                return {**cached, "cached": True}
            now = time.time()
            self.failed = {k: v for k, v in self.failed.items() if v > now}
            if query in self.failed:
                return None
            value = await usda_service.search_product(query)
            if not value:
                value = await openfoodfacts_service.search_product(query)
            if value:
                self.store(query, value)
            else:
                if len(self.failed) >= self.MAX_ENTRIES:
                    self.failed.clear()
                self.failed[query] = now + 60
            return value


nutrition_service = NutritionService()
