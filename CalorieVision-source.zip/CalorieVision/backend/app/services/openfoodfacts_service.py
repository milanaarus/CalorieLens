"""Bounded public Open Food Facts search; no API key or dataset download."""
import asyncio
import math
import os
import re
import time
import httpx


class FoodSearchUnavailable(Exception):
    pass


class FoodSearchBusy(Exception):
    pass


def parse_product(product):
    try:
        name = product.get('product_name')
        code = str(product.get('code', ''))
        if not isinstance(name, str) or not name.strip() or not re.fullmatch(r'[0-9]{8,14}', code):
            return None
        n = product.get('nutriments') or {}
        kcal = n.get('energy-kcal_100g')
        if kcal is None and n.get('energy-kj_100g') is not None:
            kcal = float(n['energy-kj_100g']) / 4.184
        # Missing macros must never silently become zero.
        values = dict(zip(('calories_per_100g','protein_per_100g','fat_per_100g','carbs_per_100g'),
                          map(float, (kcal,n.get('proteins_100g'),n.get('fat_100g'),n.get('carbohydrates_100g')))))
        if any(not math.isfinite(v) or v < 0 for v in values.values()):
            return None
        if values['calories_per_100g'] > 1000 or any(values[k] > 100 for k in values if k != 'calories_per_100g'):
            return None
        brands = product.get('brands') or []
        return {'name': name.strip()[:255], **values, 'source': 'Open Food Facts',
                'brands': ', '.join(brands) if isinstance(brands, list) else str(brands),
                'source_url': 'https://world.openfoodfacts.org/product/' + code,
                'needs_review': True}
    except (ValueError, TypeError, AttributeError):
        return None


class OpenFoodFactsService:
    def __init__(self):
        self.next_request = 0
        self.lock = asyncio.Lock()

    async def search_products(self, query):
        async with self.lock:
            if time.monotonic() < self.next_request:
                raise FoodSearchBusy()
            self.next_request = time.monotonic() + 6.1
            try:
                async with httpx.AsyncClient(timeout=10) as client:
                    response = await client.get('https://search.openfoodfacts.org/search',
                        params={'q': query, 'page_size': 12, 'langs': 'ru,en',
                                'fields': 'code,product_name,brands,nutriments'},
                        headers={'User-Agent': os.getenv('OFF_USER_AGENT',
                            'CalorieVision/1.2 (https://github.com/milanaarus/CalorieLens)')})
                    if response.status_code == 429:
                        self.next_request = time.monotonic() + 60
                        raise FoodSearchBusy()
                    response.raise_for_status()
                    payload = response.json()
                    if not isinstance(payload, dict) or not isinstance(payload.get('hits'), list) or payload.get('timed_out'):
                        raise FoodSearchUnavailable()
                    products = []; seen = set()
                    for hit in payload['hits']:
                        value = parse_product(hit)
                        if value and value['source_url'] not in seen:
                            products.append(value); seen.add(value['source_url'])
                    return products[:8]
            except (httpx.HTTPError, ValueError, TypeError) as exc:
                raise FoodSearchUnavailable() from exc

    async def search_product(self, query):
        try:
            products = await self.search_products(query)
            return products[0] if products else None
        except (FoodSearchBusy, FoodSearchUnavailable):
            return None


openfoodfacts_service = OpenFoodFactsService()
