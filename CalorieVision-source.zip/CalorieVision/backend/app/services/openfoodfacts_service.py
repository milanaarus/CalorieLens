import math
import os
import time
import httpx


class OpenFoodFactsService:
    def __init__(self):
        self.next_request = 0

    async def search_product(self, query):
        # Search limit: 10/min/IP. Do not retry rapidly or search on each keystroke.
        if time.monotonic() < self.next_request:
            return None
        self.next_request = time.monotonic() + 6.1
        try:
            async with httpx.AsyncClient(timeout=6) as client:
                response = await client.get("https://world.openfoodfacts.org/cgi/search.pl",
                    params={"search_terms": query, "json": 1, "page_size": 5,
                            "fields": "code,product_name,nutriments"},
                    headers={"User-Agent": os.getenv("OFF_USER_AGENT", "CalorieVision/1.1 (student prototype)")})
                response.raise_for_status()
                for product in response.json().get("products", []):
                    n = product.get("nutriments", {})
                    kcal = n.get("energy-kcal_100g")
                    if kcal is None and n.get("energy-kj_100g") is not None:
                        kcal = float(n["energy-kj_100g"]) / 4.184
                    if kcal is None:
                        continue
                    values = {"calories_per_100g": float(kcal),
                              "protein_per_100g": float(n.get("proteins_100g", 0)),
                              "fat_per_100g": float(n.get("fat_100g", 0)),
                              "carbs_per_100g": float(n.get("carbohydrates_100g", 0))}
                    if any(not math.isfinite(v) or v < 0 for v in values.values()):
                        continue
                    return {"name": product.get("product_name") or query, **values,
                            "source": "Open Food Facts", "needs_review": True,
                            "source_url": "https://world.openfoodfacts.org/product/" + str(product.get("code", ""))}
        except (httpx.HTTPError, ValueError, TypeError):
            return None
        return None


openfoodfacts_service = OpenFoodFactsService()
