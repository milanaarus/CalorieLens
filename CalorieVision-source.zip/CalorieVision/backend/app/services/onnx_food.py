"""CPU food detection with two bounded ONNX models; no runtime downloads."""
import ast
from pathlib import Path
import numpy as np
from PIL import Image

# A model class describes appearance, not a recipe or a measured portion.
OBJECTS = {
    'Tomato': 'Помидор', 'Bell pepper': 'Перец сладкий (уточните цвет)',
    'Apple': 'Яблоко', 'Orange': 'Апельсин', 'Strawberry': 'Клубника',
    'Raspberry': 'Малина', 'Cherry': 'Черешня', 'Broccoli': 'Брокколи сырая',
    'Carrot': 'Морковь сырая', 'Cucumber': 'Огурец', 'Cauliflower': 'Цветная капуста',
    'Eggplant': 'Баклажан', 'Potato': 'Картофель (уточните приготовление)',
    'Egg (Food)': 'Яйцо (уточните приготовление)', 'Bread': 'Хлеб (уточните вид)',
    'Pasta': 'Макароны отварные', 'Pizza': 'Пицца (уточните состав)',
    'Walnut': 'Грецкий орех', 'Almond': 'Миндаль',
}
# Restrict the secondary model: its vegetable predictions failed our smoke set.
GRAINS = {'rice': 'Рис отварной', 'pasta': 'Макароны отварные', 'banana': 'Банан',
          'chicken duck': 'Мясо птицы (уточните вид и приготовление)'}


def letterbox(image, size):
    w, h = image.size
    scale = min(size / w, size / h)
    nw, nh = round(w * scale), round(h * scale)
    dx, dy = (size - nw) // 2, (size - nh) // 2
    canvas = Image.new('RGB', (size, size), (114, 114, 114))
    canvas.paste(image.resize((nw, nh), Image.Resampling.BILINEAR), (dx, dy))
    tensor = np.asarray(canvas, dtype=np.float32).transpose(2, 0, 1)[None] / 255.0
    return tensor, (scale, dx, dy)


def iou(a, b):
    a, b = np.asarray(a), np.asarray(b)
    left = np.maximum(a[:2], b[:2]); right = np.minimum(a[2:], b[2:])
    intersection = float(np.prod(np.maximum(0, right - left)))
    union = float(np.prod(a[2:] - a[:2]) + np.prod(b[2:] - b[:2])) - intersection
    return intersection / union if union > 0 else 0


def decode(output, names, mapping, transform, image_size, threshold=0.45):
    predictions = output[0].T
    scores = predictions[:, 4:4 + len(names)]
    classes = scores.argmax(axis=1)
    confidence = scores.max(axis=1)
    # Select the best overall class BEFORE filtering, to avoid forcing food labels.
    candidates = np.where(confidence >= threshold)[0]
    candidates = candidates[np.argsort(confidence[candidates])[::-1]][:300]
    scale, dx, dy = transform; w, h = image_size
    found = []
    for index in candidates:
        original = names[int(classes[index])]
        if original not in mapping:
            continue
        x, y, bw, bh = predictions[index, :4]
        box = np.array([(x-bw/2-dx)/scale, (y-bh/2-dy)/scale,
                        (x+bw/2-dx)/scale, (y+bh/2-dy)/scale], dtype=float)
        box[[0, 2]] = box[[0, 2]].clip(0, w)
        box[[1, 3]] = box[[1, 3]].clip(0, h)
        if box[2] - box[0] < 3 or box[3] - box[1] < 3:
            continue
        if any(iou(box, other['bbox']) > 0.45 for other in found):
            continue
        found.append({'name': mapping[original], 'original_class': original,
                      'confidence': round(float(confidence[index]), 3), 'bbox': box.tolist()})
        if len(found) >= 30:
            break
    return found


def pepper_color(image, box):
    # Color refines an already detected bell pepper; never detects food by color.
    crop = image.crop(tuple(box)).resize((64, 64)).convert('HSV')
    hsv = np.asarray(crop)
    vivid = (hsv[:, :, 1] > 100) & (hsv[:, :, 2] > 60)
    count = int(vivid.sum())
    if count < 100:
        return 'Перец сладкий (уточните цвет)'
    red = ((hsv[:, :, 0] < 12) | (hsv[:, :, 0] > 240)) & vivid
    green = (hsv[:, :, 0] > 45) & (hsv[:, :, 0] < 120) & vivid
    if red.sum() / count > 0.6:
        return 'Перец красный'
    if green.sum() / count > 0.6:
        return 'Перец зелёный'
    return 'Перец сладкий (уточните цвет)'


class FoodDetector:
    def __init__(self):
        import onnxruntime as ort
        self.sessions = []
        folder = Path(__file__).resolve().parents[2] / 'models'
        for filename, mapping in [('food-objects.onnx', OBJECTS), ('food-grains.onnx', GRAINS)]:
            options = ort.SessionOptions()
            options.intra_op_num_threads = 1
            options.inter_op_num_threads = 1
            options.enable_cpu_mem_arena = False
            session = ort.InferenceSession(str(folder / filename), sess_options=options,
                                          providers=['CPUExecutionProvider'])
            names = ast.literal_eval(session.get_modelmeta().custom_metadata_map['names'])
            size = session.get_inputs()[0].shape[-1]
            self.sessions.append((session, names, mapping, size))

    def detect(self, image):
        detections = []
        for session, names, mapping, size in self.sessions:
            tensor, transform = letterbox(image, size)
            output = session.run([session.get_outputs()[0].name], {'images': tensor})[0]
            detections.extend(decode(output, names, mapping, transform, image.size))
        grouped = {}
        for detection in detections:
            if detection['original_class'] == 'Bell pepper':
                detection['name'] = pepper_color(image, detection['bbox'])
            name = detection['name']
            if name not in grouped:
                grouped[name] = {'name': name, 'confidence': detection['confidence'],
                                 'estimated_mass': 100, 'mass_confirmed': False,
                                 'recognition_method': 'food_onnx', 'boxes': []}
            item = grouped[name]
            item['confidence'] = max(item['confidence'], detection['confidence'])
            w, h = image.size
            item['boxes'].append([round(v / dimension, 5) for v, dimension in
                                  zip(detection['bbox'], (w, h, w, h))])
        return list(grouped.values())[:20]
