"""Optional remote nutrient search; no dataset download is required."""
import os
import math
import httpx


class USDAService:
    async def search_product(self, query):
        key = os.getenv("USDA_API_KEY")
        if not key:
            return None
        try:
            async with httpx.AsyncClient(timeout=6) as client:
                response = await client.get("https://api.nal.usda.gov/fdc/v1/foods/search",
                    params={"api_key": key, "query": query, "dataType": "Foundation,SR Legacy", "pageSize": 5})
                response.raise_for_status()
                for food in response.json().get("foods", []):
                    values = {n.get("nutrientId"): n.get("value") for n in food.get("foodNutrients", [])}
                    kcal = values.get(1008)
                    if kcal is None:
                        continue
                    nutrients = {"calories_per_100g": kcal, "protein_per_100g": values.get(1003, 0),
                                 "fat_per_100g": values.get(1004, 0), "carbs_per_100g": values.get(1005, 0)}
                    if any(not isinstance(v, (int, float)) or not math.isfinite(v) or v < 0 for v in nutrients.values()):
                        continue
                    return {"name": food["description"], **nutrients, "source": "USDA FoodData Central",
                            "source_url": f'https://fdc.nal.usda.gov/food-details/{food["fdcId"]}/nutrients',
                            "needs_review": True}
        except (httpx.HTTPError, ValueError, KeyError, TypeError):
            return None
        return None


usda_service = USDAService()
