"""One server for the API and the built React application."""
import os
from pathlib import Path
from fastapi.staticfiles import StaticFiles
from starlette.exceptions import HTTPException as StarletteHTTPException
from app.main import app
from app.core.database import Base, engine
from app.core.config import settings


class SPAStaticFiles(StaticFiles):
    async def get_response(self, path, scope):
        try:
            return await super().get_response(path, scope)
        except StarletteHTTPException as exc:
            if exc.status_code != 404 or scope['method'] not in {'GET', 'HEAD'}:
                raise
            # Unknown API routes and missing assets must remain real 404s.
            normalized = path.replace('\\', '/').lstrip('/')
            if normalized == 'api' or normalized.startswith('api/') or '.' in normalized.rsplit('/', 1)[-1]:
                raise
            return await super().get_response('index.html', scope)


def validate_environment():
    if len(settings.SECRET_KEY) < 32 or settings.SECRET_KEY == 'replace-with-a-long-random-secret':
        raise RuntimeError('Set SECRET_KEY to a private random value of at least 32 characters')
    if not os.getenv('DATABASE_URL'):
        raise RuntimeError('Set DATABASE_URL to a persistent database before public deployment')


@app.on_event('startup')
def prepare_database():
    validate_environment()
    # Initial schema only: existing database upgrades need explicit migrations.
    Base.metadata.create_all(bind=engine)


directory = Path(os.environ['FRONTEND_DIST']).resolve()
if not (directory / 'index.html').is_file():
    raise RuntimeError('Build the frontend and set FRONTEND_DIST to its dist directory')

# Replace the development API greeting with the site's homepage.
app.router.routes = [route for route in app.router.routes if getattr(route, 'path', None) != '/']
app.mount('/', SPAStaticFiles(directory=str(directory), html=True), name='frontend')
