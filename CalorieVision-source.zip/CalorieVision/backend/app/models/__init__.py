from app.models.user import User
from app.models.food import Food, FoodNutrition
from app.models.scan import Scan, DetectedFood
