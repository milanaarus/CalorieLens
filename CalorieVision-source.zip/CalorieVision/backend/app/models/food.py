from sqlalchemy import Column, Integer, String, Float, DateTime, ForeignKey
from sqlalchemy.sql import func
from app.core.database import Base


class Food(Base):
    __tablename__ = "foods"

    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(255), nullable=False, unique=True)
    name_ru = Column(String(255))
    category = Column(String(100))
    created_at = Column(DateTime(timezone=True), server_default=func.now())


class FoodNutrition(Base):
    __tablename__ = "food_nutrition"

    id = Column(Integer, primary_key=True, index=True)
    food_id = Column(Integer, ForeignKey("foods.id", ondelete="CASCADE"), nullable=False)
    calories_per_100g = Column(Float, nullable=False, default=0)
    protein_per_100g = Column(Float, default=0)
    fat_per_100g = Column(Float, default=0)
    carbs_per_100g = Column(Float, default=0)
    fiber_per_100g = Column(Float, default=0)
