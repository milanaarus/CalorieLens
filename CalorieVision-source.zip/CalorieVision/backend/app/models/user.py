from sqlalchemy import Column, Integer, String, Float, DateTime
from sqlalchemy.sql import func
from app.core.database import Base


class User(Base):
    __tablename__ = "users"

    id = Column(Integer, primary_key=True, index=True)
    email = Column(String(255), unique=True, nullable=False, index=True)
    hashed_password = Column(String(255), nullable=False)
    name = Column(String(255))
    weight = Column(Float, default=70.0)
    height = Column(Float, default=170.0)
    age = Column(Integer, default=25)
    daily_calorie_goal = Column(Float, default=2000.0)
    activity_level = Column(String(50), default="moderate")
    created_at = Column(DateTime(timezone=True), server_default=func.now())
