from ultralytics import YOLO

# Загружаем предобученную модель YOLOv8n (самая легкая)
model = YOLO("yolov8n.pt")

print("✅ YOLO загружен успешно!")
print(f"Модель: {model.model_name}")
