import sys
import os
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from app.core.database import engine, Base
from app.models import User, Food, FoodNutrition, Scan, DetectedFood


def init_database():
    print("🗄️  Создаем таблицы...")
    Base.metadata.create_all(bind=engine)
    print("✅ Таблицы успешно созданы!")
    print("   - users")
    print("   - foods")
    print("   - food_nutrition")
    print("   - scans")
    print("   - detected_foods")


if __name__ == "__main__":
    init_database()
