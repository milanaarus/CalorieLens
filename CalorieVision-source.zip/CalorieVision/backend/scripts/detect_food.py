from ultralytics import YOLO

# Загружаем модель
model = YOLO("yolov8n.pt")

# Распознаем объекты на фото
results = model("test_food.jpg")

# Выводим результаты
for result in results:
    print(f"\n🔍 Найдено объектов: {len(result.boxes)}")
    for box in result.boxes:
        class_id = int(box.cls[0])
        class_name = model.names[class_id]
        confidence = float(box.conf[0])
        
        if confidence > 0.3:  # Показываем только уверенные распознавания
            print(f"  • {class_name}: {confidence:.2%}")
