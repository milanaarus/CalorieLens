import unittest
import numpy as np
from PIL import Image
from app.services.onnx_food import decode, letterbox, pepper_color


class FoodPostprocessTests(unittest.TestCase):
    def test_letterbox_preserves_aspect_ratio(self):
        tensor, transform = letterbox(Image.new('RGB',(800,400)),640)
        self.assertEqual(tensor.shape,(1,3,640,640))
        self.assertEqual(transform,(.8,0,160))

    def test_non_food_best_class_not_forced_to_food(self):
        output=np.array([[[50],[50],[40],[40],[.7],[.9]]],dtype=np.float32)
        self.assertEqual(decode(output,{0:'Tomato',1:'Bowl'},{'Tomato':'Помидор'},(1,0,0),(100,100)),[])

    def test_duplicate_boxes_suppressed_and_padding_removed(self):
        output=np.array([[[320,321],[320,321],[160,160],[160,160],[.9,.8]]],dtype=np.float32)
        found=decode(output,{0:'Tomato'},{'Tomato':'Помидор'},(.8,0,160),(800,400))
        self.assertEqual(len(found),1)
        self.assertTrue(np.allclose(found[0]['bbox'],[300,100,500,300]))

    def test_color_is_only_a_pepper_refinement(self):
        self.assertEqual(pepper_color(Image.new('RGB',(100,100),(230,10,10)),[0,0,100,100]),'Перец красный')
        self.assertEqual(pepper_color(Image.new('RGB',(100,100),'white'),[0,0,100,100]),'Перец сладкий (уточните цвет)')
