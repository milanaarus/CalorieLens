"""Regression: sum full-precision portions before rounding the final total."""
import unittest
from app.services.calorie_service import CalorieService
class PortionPrecisionTests(unittest.TestCase):
    def test_three_small_portions_are_not_rounded_to_zero(self):
        service=CalorieService()
        item=service.calculate_for_item({'calories_per_100g':3.4,'protein_per_100g':1,'fat_per_100g':0,'carbs_per_100g':1},1)
        self.assertAlmostEqual(item['calories'],0.034)
        self.assertEqual(service.calculate_total([item,item,item])['total_calories'],0.1)
