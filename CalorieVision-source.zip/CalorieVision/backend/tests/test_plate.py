import asyncio
import json
import unittest
from unittest.mock import patch, AsyncMock
from app.services.food_catalog import CATALOG, find_food
from app.services.plate_service import parse_items, detect_plate
from app.services.nutrition_service import NutritionService


class PlateTests(unittest.TestCase):
    def test_catalog_unique_and_red_foods_available(self):
        self.assertGreaterEqual(len(CATALOG), 200)
        self.assertEqual(len({f['id'] for f in CATALOG}), len(CATALOG))
        self.assertEqual(len({f['name'] for f in CATALOG}), len(CATALOG))
        for name in ['Помидор', 'Перец красный', 'Клубника', 'Свёкла варёная']:
            self.assertTrue(find_food(name)['red_focus'])

    def test_model_response_cannot_invent_foods_or_weight(self):
        tomato = find_food('Помидор')
        chicken = find_food('Куриная грудка без кожи, приготовленная')
        items = parse_items(json.dumps({'foods': [{'id':tomato['id'], 'mass':800},
            {'id':tomato['id']}, {'id':'unknown'}, {'id':chicken['id']}]}))
        self.assertEqual(len(items), 2)
        self.assertEqual(items[0]['estimated_mass'], 100)
        self.assertEqual(items[0]['confidence'], 0)
        with self.assertRaises(ValueError):
            parse_items('{"foods": "not a list"}')

    def test_no_cloud_request_without_configuration(self):
        with patch.dict('os.environ', {}, clear=True), patch('httpx.AsyncClient') as client:
            with self.assertRaises(RuntimeError):
                asyncio.run(detect_plate(b'anything'))
            client.assert_not_called()

    def test_russian_food_is_translated_for_online_search(self):
        service = NutritionService()
        with patch.object(service, 'cached', return_value=None), patch.object(service, 'store'), \
             patch('app.services.nutrition_service.usda_service.search_product', new_callable=AsyncMock) as search:
            search.return_value = {'name':'cooked buckwheat'}
            result = asyncio.run(service.search_food('Плов с курицей'))
            search.assert_awaited_once_with('chicken pilaf')
            self.assertIsNotNone(result)
