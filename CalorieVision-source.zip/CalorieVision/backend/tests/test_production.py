"""Check public-serving routes in an isolated process and disposable database."""
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest


class ProductionTests(unittest.TestCase):
    def test_frontend_routes_and_api_404(self):
        with tempfile.TemporaryDirectory() as temporary:
            folder = Path(temporary)
            frontend = folder / 'dist'
            frontend.mkdir()
            (frontend / 'index.html').write_text('<html>CalorieVision test</html>', encoding='utf-8')
            env = os.environ.copy()
            env.update({
                'FRONTEND_DIST': str(frontend),
                'DATABASE_URL': 'sqlite:///' + str(folder / 'test.db').replace('\\', '/'),
                'SECRET_KEY': 'test-secret-only-for-production-route-tests',
                'PYTHONPATH': os.pathsep.join(str(Path(p).resolve()) for p in sys.path if p),
            })
            code = '''
from fastapi.testclient import TestClient
from app.production import app
from app.core.database import engine
with TestClient(app) as client:
    for route in ['/', '/login', '/scan', '/profile']:
        response = client.get(route)
        assert response.status_code == 200, (route, response.text)
        assert 'CalorieVision test' in response.text
    response = client.get('/api/nonexistent')
    assert response.status_code == 404, (response.status_code, response.text)
    assert client.get('/missing.js').status_code == 404
    assert client.get('/health').json() == {'status': 'ok'}
    assert client.get('/api/profile').status_code == 401
engine.dispose()
'''
            result = subprocess.run([sys.executable, '-c', code], env=env, capture_output=True, text=True, timeout=30)
            self.assertEqual(result.returncode, 0, result.stderr)


if __name__ == '__main__':
    unittest.main()
