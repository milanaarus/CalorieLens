import asyncio
import tempfile
import unittest
from pathlib import Path
from unittest.mock import AsyncMock, patch
from app.services.openfoodfacts_service import parse_product, FoodSearchBusy, FoodSearchUnavailable
from app.services.nutrition_service import NutritionService


class OnlineNutritionTests(unittest.TestCase):
    def test_incomplete_or_invalid_macros_are_not_zero_filled(self):
        p = {'product_name':'Pizza','code':'5024530005316','nutriments':{'energy-kcal_100g':256}}
        self.assertIsNone(parse_product(p))
        p['nutriments'].update(proteins_100g=12,fat_100g=8.56,carbohydrates_100g=31.7)
        self.assertEqual(parse_product(p)['protein_per_100g'],12)
        p['nutriments']['fat_100g'] = float('nan')
        self.assertIsNone(parse_product(p))

    def test_kilojoules_conversion(self):
        p = {'product_name':'Test','code':'12345678','nutriments':{'energy-kj_100g':418.4,'proteins_100g':1,'fat_100g':0,'carbohydrates_100g':24}}
        self.assertAlmostEqual(parse_product(p)['calories_per_100g'],100)

    def test_choices_persist_without_repeat_request_and_local_stays_offline(self):
        async def check():
            with tempfile.TemporaryDirectory() as tmp:
                s = NutritionService();s.path=Path(tmp)/'cache.db'
                choices = [{'name':'Pizza A','calories_per_100g':256},{'name':'Pizza B','calories_per_100g':259}]
                with patch('app.services.nutrition_service.openfoodfacts_service.search_products',new=AsyncMock(return_value=choices)) as remote:
                    result=await s.search_choices('Пицца (уточните состав)')
                    self.assertEqual(len(result),2)
                    remote.assert_awaited_once_with('pizza')
                    second=NutritionService();second.path=s.path
                    self.assertTrue((await second.search_choices('Пицца (уточните состав)'))[0]['cached'])
                    self.assertEqual((await s.search_choices('Банан'))[0]['calories_per_100g'],89)
                    self.assertEqual(remote.await_count,1)
        asyncio.run(check())

    def test_remote_failure_is_not_cached_as_no_results(self):
        async def check():
            with tempfile.TemporaryDirectory() as tmp:
                s=NutritionService();s.path=Path(tmp)/'cache.db'
                with patch('app.services.nutrition_service.openfoodfacts_service.search_products',new=AsyncMock(side_effect=FoodSearchUnavailable)):
                    with self.assertRaises(FoodSearchUnavailable):await s.search_choices('pizza')
                with patch('app.services.nutrition_service.openfoodfacts_service.search_products',new=AsyncMock(return_value=[{'name':'Pizza'}])):
                    self.assertEqual((await s.search_choices('pizza'))[0]['name'],'Pizza')
        asyncio.run(check())
