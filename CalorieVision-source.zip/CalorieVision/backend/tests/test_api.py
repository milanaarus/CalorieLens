"""Integration checks with a disposable SQLite DB and deterministic CV model.

Run: python -m unittest discover -s tests -v
The tests deliberately do not download model weights or call external APIs.
"""
import asyncio
import io
import os
import sys
import tempfile
import types
import unittest
from pathlib import Path
from unittest.mock import AsyncMock, patch
from threading import Event

temporary = tempfile.TemporaryDirectory()
os.environ['DATABASE_URL'] = 'sqlite:///' + str(Path(temporary.name)/'test.db').replace('\\','/')
os.environ['NUTRITION_CACHE_PATH'] = str(Path(temporary.name)/'cache.sqlite3')
os.environ['SECRET_KEY'] = 'only-for-disposable-integration-tests'
os.environ.pop('USDA_API_KEY', None)

from fastapi.testclient import TestClient
from PIL import Image
from app.main import app
from app.core.database import Base, engine
from app.services.nutrition_service import NutritionService

class DiaryTests(unittest.TestCase):
    def test_photo_mass_must_be_confirmed(self):
        meal={'items':[{'name':'Банан','estimated_mass':100,'confidence':.8,'nutrition_per_100g':{'calories':89}}]}
        self.assertEqual(self.client.post('/api/scans',headers=self.tokens[0],json=meal).status_code,422)
        meal['items'][0]['mass_confirmed']=True
        response=self.client.post('/api/scans',headers=self.tokens[0],json=meal)
        self.assertEqual(response.status_code,200)
        self.client.delete('/api/scans/'+str(response.json()['scan_id']),headers=self.tokens[0])

    def test_basic_plate_works_without_external_services(self):
        with patch('httpx.AsyncClient', side_effect=AssertionError('Network must not be used')):
            foods = self.client.get('/api/foods/catalog', headers=self.tokens[0]).json()
            self.assertEqual(foods['local_count'],33)
            self.assertFalse(foods['cloud_available'])
            meal = []
            expected = 0
            for name, mass in [('Рис отварной',150),('Куриная грудка без кожи, приготовленная',100),('Помидор',100),('Перец красный',50)]:
                response = self.client.get('/api/foods/search',params={'query':name},headers=self.tokens[0])
                self.assertEqual(response.status_code,200)
                food = response.json()['product']
                self.assertIn('fdc.nal.usda.gov',food['source_url'])
                n = {k:food[k+'_per_100g'] for k in ('calories','protein','fat','carbs')}
                expected += n['calories'] * mass / 100
                meal.append({'name':name,'estimated_mass':mass,'nutrition_per_100g':n})
            saved = self.client.post('/api/scans',headers=self.tokens[0],json={'items':meal}).json()
            self.assertAlmostEqual(saved['total_calories'],round(expected,1))
            detail = self.client.get('/api/scans/'+str(saved['scan_id']),headers=self.tokens[0]).json()
            self.assertEqual(len(detail['scan']['items']) if 'scan' in detail else len(detail['items']),4)
            self.client.delete('/api/scans/'+str(saved['scan_id']),headers=self.tokens[0])

    def test_recognized_food_without_nutrition_is_not_lost(self):
        output = io.BytesIO(); Image.new('RGB',(20,20)).save(output,format='PNG')
        with patch('app.main.cv_service.detect_food', new_callable=AsyncMock) as detect:
            detect.return_value = [{'name':'pizza', 'estimated_mass':250, 'confidence':.8}]
            response = self.client.post('/api/scan', headers=self.tokens[0],
                files={'file':('plate.png',output.getvalue(),'image/png')})
        self.assertEqual(response.status_code,200)
        item = response.json()['items'][0]
        self.assertEqual(item['name'],'pizza')
        self.assertTrue(item['nutrition_missing'])

    @classmethod
    def tearDownClass(cls):
        cls.client.close()
        cls.detector_patch.stop()
        engine.dispose()
        temporary.cleanup()

    @classmethod
    def setUpClass(cls):
        cls.detector_patch = patch('app.services.onnx_food.FoodDetector')
        detector = cls.detector_patch.start().return_value
        detector.detect.return_value = [{'name':'Банан','confidence':.9,'estimated_mass':100,'mass_confirmed':False,'boxes':[[0,0,1,1]]}]
        Base.metadata.create_all(engine)
        cls.client = TestClient(app)
        cls.tokens=[]
        for i in range(2):
            response=cls.client.post('/api/auth/register',json={'email':f'user{i}@example.org','password':'test-pass-123','name':f'Test {i}'})
            assert response.status_code==200, response.text
            cls.tokens.append({'Authorization':'Bearer '+response.json()['token']})

    def test_01_analyze_does_not_save_and_preserves_boxes(self):
        image=Image.new('RGB',(50,50)); output=io.BytesIO(); image.save(output,format='PNG')
        response=self.client.post('/api/scan',headers=self.tokens[0],files={'file':('meal.png',output.getvalue(),'image/png')})
        self.assertEqual(response.status_code,200,response.text)
        result=response.json()
        self.assertEqual(len(result['items']),1)
        self.assertEqual(result['items'][0]['boxes'], [[0,0,1,1]])
        self.assertFalse(result['items'][0]['mass_confirmed'])
        self.assertEqual(result['items'][0]['estimated_mass'],100)
        self.assertEqual(self.client.get('/api/scans',headers=self.tokens[0]).json()['total'],0)

    def test_02_save_calculations_and_isolation(self):
        meal={'meal_type':'lunch','items':[{'name':'Test food','estimated_mass':150,'nutrition_per_100g':{'calories':200,'protein':10,'fat':5,'carbs':25}}]}
        response=self.client.post('/api/scans',headers=self.tokens[0],json=meal)
        self.assertEqual(response.status_code,200,response.text)
        result=response.json(); self.assertEqual(result['total_calories'],300)
        self.assertEqual(result['total_protein'],15)
        meal_id=result['scan_id']
        self.assertEqual(self.client.get(f'/api/scans/{meal_id}',headers=self.tokens[1]).status_code,404)
        self.assertEqual(self.client.delete(f'/api/scans/{meal_id}',headers=self.tokens[1]).status_code,404)
        self.assertEqual(self.client.get('/api/stats/summary',headers=self.tokens[1]).json()['total']['count'],0)
        self.assertEqual(self.client.get('/api/stats/summary',headers=self.tokens[0]).json()['total']['calories'],300)
        profile=self.client.get('/api/profile',headers=self.tokens[1]).json()
        self.assertEqual(profile['email'],'user1@example.org')
        self.assertEqual(self.client.delete(f'/api/scans/{meal_id}',headers=self.tokens[0]).status_code,200)
        self.assertEqual(self.client.get('/api/scans',headers=self.tokens[0]).json()['total'],0)

    def test_03_auth_and_input_validation(self):
        for route in ['/api/scans','/api/profile','/api/stats/weekly','/api/stats/summary','/api/profile/stats']:
            self.assertEqual(self.client.get(route).status_code,401,route)
        invalid={'items':[{'name':'test','estimated_mass':-1,'nutrition_per_100g':{'calories':100}}]}
        self.assertEqual(self.client.post('/api/scans',headers=self.tokens[0],json=invalid).status_code,422)
        self.assertEqual(self.client.post('/api/scans',headers=self.tokens[0],json={'items':[]}).status_code,422)
        self.assertEqual(self.client.post('/api/scan',headers=self.tokens[0],files={'file':('bad.png',b'not an image','image/png')}).status_code,400)

    def test_04_cache_persists_and_avoids_repeat_remote_request(self):
        async def check():
            service=NutritionService()
            data={'name':'Example product','calories_per_100g':123,'source':'test'}
            with patch('app.services.nutrition_service.usda_service.search_product',new=AsyncMock(return_value=None)), patch('app.services.nutrition_service.openfoodfacts_service.search_product',new=AsyncMock(return_value=data)) as remote:
                self.assertEqual((await service.search_food('unique test food'))['calories_per_100g'],123)
                second=NutritionService()
                self.assertTrue((await second.search_food('unique test food'))['cached'])
                self.assertEqual(remote.await_count,1)
                self.assertEqual((await service.search_food('банан'))['calories_per_100g'],89)
                self.assertIsNone(await service.search_food('pizza',allow_remote=False))
        asyncio.run(check())

    def test_05_email_any_domain_and_case_normalization(self):
        response=self.client.post('/api/auth/register',json={'email':' Visitor@Personal.Example ','password':'visitor-test-123','name':'Visitor'})
        self.assertEqual(response.status_code,200,response.text)
        self.assertEqual(response.json()['user']['email'],'visitor@personal.example')
        login=self.client.post('/api/auth/login',json={'email':'VISITOR@PERSONAL.EXAMPLE','password':'visitor-test-123'})
        self.assertEqual(login.status_code,200,login.text)
        duplicate=self.client.post('/api/auth/register',json={'email':'VISITOR@PERSONAL.EXAMPLE','password':'other-test-123','name':'Duplicate'})
        self.assertEqual(duplicate.status_code,400)
        self.assertEqual(self.client.post('/api/auth/register',json={'email':'invalid-email','password':'test-pass-123','name':'Invalid'}).status_code,422)

    def test_06_inference_does_not_block_async_loop(self):
        from app.services.cv_service import CVService
        entered, release = Event(), Event()
        service = CVService()
        def slow_inference(_):
            entered.set()
            release.wait(timeout=2)
            return []
        async def check():
            with patch.object(service, '_detect_food', side_effect=slow_inference):
                task = asyncio.create_task(service.detect_food(b'test'))
                try:
                    self.assertTrue(await asyncio.to_thread(entered.wait, 1))
                    self.assertFalse(task.done(), 'Inference blocked the async event loop')
                finally:
                    release.set()
                    await task
        asyncio.run(check())

if __name__=='__main__': unittest.main()
