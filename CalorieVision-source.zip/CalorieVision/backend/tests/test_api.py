"""Integration checks with a disposable SQLite DB and deterministic CV model.

Run: python -m unittest discover -s tests -v
The tests deliberately do not download model weights or call external APIs.
"""
import asyncio
import io
import os
import sys
import tempfile
import types
import unittest
from pathlib import Path
from unittest.mock import AsyncMock, patch
from threading import Event

temporary = tempfile.TemporaryDirectory()
os.environ['DATABASE_URL'] = 'sqlite:///' + str(Path(temporary.name)/'test.db').replace('\\','/')
os.environ['NUTRITION_CACHE_PATH'] = str(Path(temporary.name)/'cache.sqlite3')
os.environ['SECRET_KEY'] = 'only-for-disposable-integration-tests'
os.environ.pop('USDA_API_KEY', None)

class Coordinates(list):
    def tolist(self): return list(self)

class FakeModel:
    names = {0:'banana', 1:'bowl'}
    def __init__(self, *args): pass
    def __call__(self, image, **kwargs):
        return [types.SimpleNamespace(boxes=[
            types.SimpleNamespace(cls=[i],conf=[.9],xyxy=[Coordinates([0,0,30,30])]) for i in (0,1)
        ])]

sys.modules['ultralytics'] = types.SimpleNamespace(YOLO=FakeModel)
from fastapi.testclient import TestClient
from PIL import Image
from app.main import app
from app.core.database import Base, engine
from app.services.nutrition_service import NutritionService

class DiaryTests(unittest.TestCase):
    @classmethod
    def tearDownClass(cls):
        cls.client.close()
        engine.dispose()
        temporary.cleanup()

    @classmethod
    def setUpClass(cls):
        Base.metadata.create_all(engine)
        cls.client = TestClient(app)
        cls.tokens=[]
        for i in range(2):
            response=cls.client.post('/api/auth/register',json={'email':f'user{i}@example.org','password':'test-pass-123','name':f'Test {i}'})
            assert response.status_code==200, response.text
            cls.tokens.append({'Authorization':'Bearer '+response.json()['token']})

    def test_01_analyze_does_not_save_or_count_bowl(self):
        image=Image.new('RGB',(50,50)); output=io.BytesIO(); image.save(output,format='PNG')
        response=self.client.post('/api/scan',headers=self.tokens[0],files={'file':('meal.png',output.getvalue(),'image/png')})
        self.assertEqual(response.status_code,200,response.text)
        result=response.json()
        self.assertEqual(len(result['items']),1)
        self.assertEqual(result['items'][0]['estimated_mass'],120)
        self.assertEqual(self.client.get('/api/scans',headers=self.tokens[0]).json()['total'],0)

    def test_02_save_calculations_and_isolation(self):
        meal={'meal_type':'lunch','items':[{'name':'Test food','estimated_mass':150,'nutrition_per_100g':{'calories':200,'protein':10,'fat':5,'carbs':25}}]}
        response=self.client.post('/api/scans',headers=self.tokens[0],json=meal)
        self.assertEqual(response.status_code,200,response.text)
        result=response.json(); self.assertEqual(result['total_calories'],300)
        self.assertEqual(result['total_protein'],15)
        meal_id=result['scan_id']
        self.assertEqual(self.client.get(f'/api/scans/{meal_id}',headers=self.tokens[1]).status_code,404)
        self.assertEqual(self.client.delete(f'/api/scans/{meal_id}',headers=self.tokens[1]).status_code,404)
        self.assertEqual(self.client.get('/api/stats/summary',headers=self.tokens[1]).json()['total']['count'],0)
        self.assertEqual(self.client.get('/api/stats/summary',headers=self.tokens[0]).json()['total']['calories'],300)
        profile=self.client.get('/api/profile',headers=self.tokens[1]).json()
        self.assertEqual(profile['email'],'user1@example.org')
        self.assertEqual(self.client.delete(f'/api/scans/{meal_id}',headers=self.tokens[0]).status_code,200)
        self.assertEqual(self.client.get('/api/scans',headers=self.tokens[0]).json()['total'],0)

    def test_03_auth_and_input_validation(self):
        for route in ['/api/scans','/api/profile','/api/stats/weekly','/api/stats/summary','/api/profile/stats']:
            self.assertEqual(self.client.get(route).status_code,401,route)
        invalid={'items':[{'name':'test','estimated_mass':-1,'nutrition_per_100g':{'calories':100}}]}
        self.assertEqual(self.client.post('/api/scans',headers=self.tokens[0],json=invalid).status_code,422)
        self.assertEqual(self.client.post('/api/scans',headers=self.tokens[0],json={'items':[]}).status_code,422)
        self.assertEqual(self.client.post('/api/scan',headers=self.tokens[0],files={'file':('bad.png',b'not an image','image/png')}).status_code,400)

    def test_04_cache_persists_and_avoids_repeat_remote_request(self):
        async def check():
            service=NutritionService()
            data={'name':'Example product','calories_per_100g':123,'source':'test'}
            with patch('app.services.nutrition_service.usda_service.search_product',new=AsyncMock(return_value=None)), patch('app.services.nutrition_service.openfoodfacts_service.search_product',new=AsyncMock(return_value=data)) as remote:
                self.assertEqual((await service.search_food('unique test food'))['calories_per_100g'],123)
                second=NutritionService()
                self.assertTrue((await second.search_food('unique test food'))['cached'])
                self.assertEqual(remote.await_count,1)
                self.assertEqual((await service.search_food('банан'))['calories_per_100g'],89)
                self.assertIsNone(await service.search_food('pizza',allow_remote=False))
        asyncio.run(check())

    def test_05_email_any_domain_and_case_normalization(self):
        response=self.client.post('/api/auth/register',json={'email':' Visitor@Personal.Example ','password':'visitor-test-123','name':'Visitor'})
        self.assertEqual(response.status_code,200,response.text)
        self.assertEqual(response.json()['user']['email'],'visitor@personal.example')
        login=self.client.post('/api/auth/login',json={'email':'VISITOR@PERSONAL.EXAMPLE','password':'visitor-test-123'})
        self.assertEqual(login.status_code,200,login.text)
        duplicate=self.client.post('/api/auth/register',json={'email':'VISITOR@PERSONAL.EXAMPLE','password':'other-test-123','name':'Duplicate'})
        self.assertEqual(duplicate.status_code,400)
        self.assertEqual(self.client.post('/api/auth/register',json={'email':'invalid-email','password':'test-pass-123','name':'Invalid'}).status_code,422)

    def test_06_inference_does_not_block_async_loop(self):
        from app.services.cv_service import CVService
        entered, release = Event(), Event()
        service = CVService()
        def slow_inference(_):
            entered.set()
            release.wait(timeout=2)
            return []
        async def check():
            with patch.object(service, '_detect_food', side_effect=slow_inference):
                task = asyncio.create_task(service.detect_food(b'test'))
                try:
                    self.assertTrue(await asyncio.to_thread(entered.wait, 1))
                    self.assertFalse(task.done(), 'Inference blocked the async event loop')
                finally:
                    release.set()
                    await task
        asyncio.run(check())

if __name__=='__main__': unittest.main()
